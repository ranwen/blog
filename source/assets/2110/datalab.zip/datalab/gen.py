txt=""
for expv in range(0,127):
 txt=txt+"case 0x%x:\n"%((expv)<<23)
 txt=txt+"case 0x%x:\n"%((expv+256)<<23)
txt=txt+"return 0;\n"
for expv in range(158,256):
 txt=txt+"case 0x%x:\n"%((expv)<<23)
 txt=txt+"case 0x%x:\n"%((expv+256)<<23)
txt=txt+"return 0x80000000u;\n"
for expv in range(127,158):
 cdl=""
 if expv>=150:
  cdl="movlv=%d;"%(expv-150)
 else:
  cdl="movrv=%d;"%(150-expv)
 txt=txt+"case 0x%x: %s break;\n"%((expv)<<23,cdl)
 txt=txt+"case 0x%x: %s sv=1; break;\n"%((expv+256)<<23,cdl)
print(txt)