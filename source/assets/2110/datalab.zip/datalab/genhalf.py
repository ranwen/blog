TABC=0
def rprint(st):
    print(' '*TABC*4,end='')
    print(st)

rprint("int alu0=0,alu1=0,alu2=0;")
rprint("int reg0=1,reg1=0,reg2=0,reg3=0,reg4=0,reg5=0,reg6=0,reg7=0;")
rprint("int bw"+"=0,bw".join(list(map(str,range(32))))+"=0;")
rprint("int cw"+"=0,cw".join(list(map(str,range(32))))+"=0;")
rprint("int nowl=1;")
rprint("int expv=0;")

#reg0 is shifted
#reg1 add now bit
#reg2 add carry bit

def gen_add_begin(adw):
    pd=("reg1=0;if(bw%d){if(cw%d){if(reg2){reg1=1;}else{reg2=1;}}\
else{if(reg2){}else{reg1=1;}}}\
else{if(cw%d){if(reg2){}else{reg1=1;}}\
else{if(reg2){reg1=1;reg2=0;}else{}}}"%(adw,adw,adw))+\
    ("alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0x%x;}"%(0xffffffff^(2**adw)))
    if adw<1:
        return pd
    pd2=("reg1=0;if(bw%d){if(reg2){}else{reg1=1;}}\
else{if(reg2){reg1=1;reg2=0;}else{}}"%adw)+("alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0x%x;}"%(0xffffffff^(2**adw)))
    if adw<23:
        return pd2
    return pd

def show_before():
    global TABC
    rprint("switch(nowl)")
    rprint('{')
    TABC+=1
    rprint("case 1: alu0=uf;alu1=0xff800003;break;")
    for i in range(32):
        rprint("case %d: alu1=0x%x;break;"%(2+i,2**i))
    for i in range(32):
        rprint("case %d: %s break;"%(i+34,gen_add_begin(i)))
    TABC-=1
    rprint('}')

def show_after():
    global TABC
    rprint("switch(nowl)")
    rprint('{')
    TABC+=1
    rprint("case 1: expv=alu2;")
    rprint("switch(expv)")
    rprint("{")
    TABC+=1
    rprint("case 0x7f800000: case 0x7f800001: case 0x7f800002: case 0x7f800003: case 0xff800000: case 0xff800001: case 0xff800002: case 0xff800003: return uf;")
    rprint("case 0: case 1: case 2: case 0x800000: case 0x800001: case 0x800002: break;")
    rprint("case 3: case 0x800003: cw0=1;break;")
    rprint("case 0x80000000: case 0x80000001: case 0x80000002: case 0x80800000: case 0x80800001: case 0x80800002: cw30=1;break;")
    rprint("case 0x80000003: case 0x80800003: cw30=1;cw0=1;break;")
    rprint("default: reg0=0;cw23=1;cw24=1;cw25=1;cw26=1;cw27=1;cw28=1;cw29=1;cw30=1;cw31=1;break;")
    TABC-=1
    rprint('}nowl=2;break;')
    for i in range(31):
        rprint("case %d: bw%d=alu2;nowl=%d;break;"%(2+i,i,3+i))
    rprint("case %d: bw%d=alu2;nowl=%d;if(reg0){%s}alu2=0xffffffff;break;"%(2+31,31,3+31,("".join(["bw%d=bw%d;"%y for y in [(x,x+1) for x in range(31)]]+["bw31=0;"]))))
    for i in range(31):
        rprint("case %d: nowl=%d;break;"%(34+i,35+i))
    rprint("case %d: nowl=%d;reg7=alu2;break;"%(34+31,0))
    TABC-=1
    rprint('}')

rprint("while(nowl)")
rprint("{")
TABC+=1

show_before()
rprint("alu2=alu0&alu1;")
show_after()

TABC-=1
rprint("}")
rprint("return reg7;")