sar1=[]
sal1=[]

for a in range(256):
    if a==0:
        continue
    for b in range(256):
        if (b&31)==0:
            continue
        if b>31:
            continue
        va=(a>>(b&31))%(2**32)
        vb=(a<<(b&31))%(2**32)
        if va>255:
            sar1.append(va)
        if vb>255:
            sal1.append(vb)

print(len(sar1))
print(len(sal1))

print(len(set(sar1)))
print(len(set(sal1)))