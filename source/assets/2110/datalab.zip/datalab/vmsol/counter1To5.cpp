#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<map>
#include<unistd.h>
using namespace std;
template<typename __T>
inline void read(__T &x)
{
    x=0;
    int f=1;char c=getchar();
    while(!isdigit(c)){if(c=='-')   f=-1;c=getchar();}
    while(isdigit(c))   {x=x*10+c-'0';c=getchar();}
    x*=f;
}
enum OPCODE: unsigned char
{
    PUSH=0x00,
    LOAD=0x10,
    STOR,
    INOT=0x20,
    IAND,
    IOR,
    IXOR,
    IADD=0x30,
    ISAR=0x40,
    ISAL,
    BNOT=0x50,
    INVALID=0xff
};
struct code
{
    OPCODE opcode;
    int val;
};

const int FORKC=16;

const int MAX_OPS=10;
const int MAX_CHECK_SAMPLES=1;
const int MAX_TEST_SAMPLES=5;
const int MAX_STORAGE=4;
const int INPUT_SIZE=1;
struct input_t
{
    int s[INPUT_SIZE];
};
int rightFunction(input_t inp)
{
    int x=inp.s[0];
    return x==5?1:x+1;
}
input_t getSample(int id)
{
    input_t ret;
    ret.s[0]=id+1;
    return ret;
}
int getCodes(code* arr,int stackDepth,int storageSize)
{
    int tot=0;
    //PUSH
    for(int i=0;i<=16;i++)
        arr[tot++]=code{PUSH,i};
    arr[tot++]=code{PUSH,27};
    arr[tot++]=code{PUSH,28};
    arr[tot++]=code{PUSH,29};
    arr[tot++]=code{PUSH,30};
    arr[tot++]=code{PUSH,31};
    arr[tot++]=code{PUSH,32};
    //LOAD
    for(int i=0;i<storageSize;i++)
        arr[tot++]=code{LOAD,i};
    if(stackDepth<1)    return tot;
    //STOR
    if(storageSize<MAX_STORAGE)
        arr[tot++]=code{STOR,0};
    //CALC
    arr[tot++]=code{INOT,0};
    arr[tot++]=code{BNOT,0};
    if(stackDepth<2)    return tot;
    arr[tot++]=code{IAND,0};
    arr[tot++]=code{IOR,0};
    //arr[tot++]=code{IXOR,0};
    arr[tot++]=code{IADD,0};
    arr[tot++]=code{ISAR,0};
    arr[tot++]=code{ISAL,0};
    return tot;
}
const int MAX_CODES=50;


struct runtime
{
    int stack[MAX_OPS];
    int stop;
    int storage[MAX_STORAGE];
    int ttop;
    runtime()
    {
        stop=ttop=0;
    }
    runtime(input_t input)
    {
        stop=0;
        ttop=INPUT_SIZE;
        for(int i=0;i<INPUT_SIZE;i++)
            storage[i]=input.s[i];
    }
    int spop()
    {
        return stack[--stop];
    }
    void spush(int x)
    {
        stack[stop++]=x;
    }
};

bool runCode(runtime& state,code nowcode)
{
    int a,b;
    switch (nowcode.opcode)
    {
        case PUSH:
        state.spush(nowcode.val);
        break;
        case LOAD:
        state.spush(state.storage[nowcode.val]);
        break;
        case STOR:
        state.storage[state.ttop++]=state.spop();
        break;
        case INOT:
        a=state.spop();
        state.spush(~a);
        break;
        case BNOT:
        a=state.spop();
        state.spush(!a);
        break;
        case IAND:
        a=state.spop();
        b=state.spop();
        state.spush(a&b);
        break;
        case IOR:
        a=state.spop();
        b=state.spop();
        state.spush(a|b);
        break;
        case IXOR:
        a=state.spop();
        b=state.spop();
        state.spush(a^b);
        break;
        case IADD:
        a=state.spop();
        b=state.spop();
        state.spush(a+b);
        break;
        case ISAR:
        a=state.spop();
        b=state.spop();
        state.spush(a>>b);
        break;
        case ISAL:
        a=state.spop();
        b=state.spop();
        state.spush(a<<b);
        break;
        default:
        cerr<<"ERROR "<<nowcode.opcode<<endl;
        return 0;
    }
    return 1;
}
bool checkAll(code* codes,int codel)
{
    for(int i=0;i<MAX_TEST_SAMPLES;i++)
    {
        input_t ni=getSample(i);
        int no=rightFunction(ni);
        runtime nowrt(ni);
        for(int j=0;j<codel;j++)
        {
            bool g=runCode(nowrt,codes[j]);
            if(!g)  return 0;
        }
        if(nowrt.stop<1)    return 0;
        int ans=nowrt.spop();
        if(ans!=no) return 0;
    }
    return 1;
}

int countCOps(code* codes,int codel)
{
    int cnt=0;
    for(int i=0;i<codel;i++)
        if(codes[i].opcode>=INOT && codes[i].opcode<=BNOT)  cnt++;
    return cnt;
}

struct runtimechecker
{
    runtime s[MAX_CHECK_SAMPLES];
    runtimechecker()
    {
        for(int i=0;i<MAX_CHECK_SAMPLES;i++)
            s[i]=runtime(getSample(i));
    }
    runtimechecker(input_t* inps)
    {
        for(int i=0;i<MAX_CHECK_SAMPLES;i++)
            s[i]=runtime(inps[i]);
    }
    bool runCode(code nowcode)
    {
        bool flag=1;
        for(int i=0;i<MAX_CHECK_SAMPLES;i++)
            flag&=(::runCode(s[i],nowcode));
        return flag;
    }
};

int ranss[MAX_CHECK_SAMPLES];
code path[MAX_OPS];
void dfs(runtimechecker& nows,int depth)
{
    if(depth>=MAX_OPS)   return;
    int slen=nows.s[0].stop;
    if(depth+slen-1>=MAX_OPS)   return;
    //check right
    bool flag=1;
    for(int i=0;i<MAX_CHECK_SAMPLES;i++)
    {
        if(nows.s[i].stop<1)
        {
            flag=0;
            break;
        }
        runtime& rt=nows.s[i];
        if(rt.stack[rt.stop-1]!=ranss[i])
        {
            flag=0;
            break;
        }
    }
    if(flag)
    {
        if(checkAll(path,depth))
        {
            cout<<"FOUND"<<endl;
            for(int i=0;i<depth;i++)
                cout<<path[i].opcode<<' '<<path[i].val<<endl;
            return;
        }
    }
    int tlen=nows.s[0].ttop;
    code nexs[MAX_CODES];
    int rlen=getCodes(nexs,slen,tlen);
    for(int i=0;i<rlen;i++)
    {
        runtimechecker nt=nows;
        nt.runCode(nexs[i]);
        path[depth]=nexs[i];
        dfs(nt,depth+1);
    }
    return;
}

void search()
{
    int pc=0;
    while(pc+1<FORKC)
    {
        pid_t fp=fork();
        if(fp<0)
        {
            cerr<<"ERR "<<(int)(fp)<<endl;
            exit(0);
        }
        if(fp==0)   break;
        pc++;
    }
    runtimechecker inst;
    for(int i=0;i<MAX_CHECK_SAMPLES;i++)
        ranss[i]=rightFunction(getSample(i));
    int slen=inst.s[0].stop;
    int tlen=inst.s[0].ttop;
    code nexs[MAX_CODES];
    int rlen=getCodes(nexs,slen,tlen);
    for(int i=pc;i<rlen;i+=FORKC)
    {
        runtimechecker nt=inst;
        nt.runCode(nexs[i]);
        path[0]=nexs[i];
        dfs(nt,1);
    }
}

void test()
{
    code testcodes[MAX_CODES];
    int len=getCodes(testcodes,5,2);
    for(int i=0;i<len;i++)
        cout<<testcodes[i].opcode<<' '<<testcodes[i].val<<endl;
    code mo4[5]=
    {code{PUSH,1},code{LOAD,0},code{IADD,1},code{PUSH,3},code{IAND,0}};
    cout<<checkAll(mo4,5)<<endl;
    code mo4w[5]=
    {code{PUSH,1},code{LOAD,0},code{IADD,1},code{PUSH,5},code{IAND,0}};
    cout<<checkAll(mo4w,5)<<endl;
    search();
}
int main()
{
    //test();
    search();
	return 0;
}
