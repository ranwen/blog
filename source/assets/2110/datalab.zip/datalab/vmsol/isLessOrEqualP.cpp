#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<map>
#include<unistd.h>
#include<sys/msg.h>
#include <sys/wait.h>
#include <sys/types.h>
#include<errno.h>
using namespace std;
template<typename __T>
inline void read(__T &x)
{
    x=0;
    int f=1;char c=getchar();
    while(!isdigit(c)){if(c=='-')   f=-1;c=getchar();}
    while(isdigit(c))   {x=x*10+c-'0';c=getchar();}
    x*=f;
}
enum OPCODE: unsigned char
{
    PUSH=0x00,
    LOAD=0x10,
    STOR,
    INOT=0x20,
    IAND,
    IOR,
    IXOR,
    IADD=0x30,
    ISAR=0x40,
    ISAL,
    BNOT=0x50,
    INVALID=0xff
};
struct code
{
    OPCODE opcode;
    int val1;
    int val2;
};

const int MAX_OPS=5;
const int MAX_CHECK_SAMPLES=1;
const int MAX_TEST_SAMPLES=8;
const int INPUT_SIZE=3;
const int FORKC=16;
const int FORKD=MAX_OPS/2;
struct input_t
{
    int s[INPUT_SIZE];
};
int rightFunction(input_t inp)
{
    int x=inp.s[0];
    int y=inp.s[1];
    int cha=inp.s[2];
    int difh=x^y;
    return (((cha)^((x^cha)&difh))>>31)&1;
}
input_t getSample(int id)
{
    input_t ret;
    int x=0;
    int y=0;
    int z=0;
    switch (id%2)
    {
        case 0:
        x=0;
        break;
        case 1:
        x=~0;
        break;
    }
    switch ((id/2)%2)
    {
        case 0:
        y=0;
        break;
        case 1:
        y=~0;
    }
    switch ((id/4))
    {
        case 0:
        z=0;
        break;
        case 1:
        z=~0;
    }
    ret.s[0]=x;
    ret.s[1]=y;
    ret.s[2]=z;
    return ret;
}
const int constIntList[]={0,1,31,32};
const int constIntListLen=4;
const int storagePrefix=0x80000000;
int salConst[constIntListLen*constIntListLen];
int salConstLen=0;

int getCodes(code* arr,int storageSize)
{
    #define USE_INOT
    #define USE_BNOT
    #define USE_IAND
    #define USE_IOR
    #define USE_IXOR
    #define USE_IADD
    #define USE_ISAR
    #define USE_ISAL
    int tot=0;
    //single
    //INOT
    #ifdef USE_INOT
    for(int i=0;i<constIntListLen;i++)
    {
        int mx=~constIntList[i];
        if(mx>=0 && mx<=255)    continue;
        arr[tot++]=code{INOT,~mx,0};
    }
    for(int i=0;i<storageSize;i++)
        arr[tot++]=code{INOT,i|storagePrefix,0};
    #endif
    //BNOT
    #ifdef USE_BNOT
    for(int i=0;i<storageSize;i++)
        arr[tot++]=code{BNOT,i|storagePrefix,0};
    #endif
    //bin
    //IAND&IOR&IXOR&IADD  we assume donnot use const+const
    for(int i=0;i<storageSize;i++)
    {
        int ccv=i|storagePrefix;
        for(int j=0;j<constIntListLen;j++)
        {
            int mx=constIntList[j];
            if(mx==0)   continue;
            #ifdef USE_IAND
            arr[tot++]=code{IAND,ccv,mx};
            #endif
            #ifdef USE_IOR
            arr[tot++]=code{IOR,ccv,mx};
            #endif
            #ifdef USE_IXOR
            arr[tot++]=code{IXOR,ccv,mx};
            #endif
            #ifdef USE_IADD
            arr[tot++]=code{IADD,ccv,mx};
            #endif
        }
        for(int j=i+1;j<storageSize;j++)
        {
            int cdv=j|storagePrefix;
            #ifdef USE_IAND
            arr[tot++]=code{IAND,ccv,cdv};
            #endif
            #ifdef USE_IOR
            arr[tot++]=code{IOR,ccv,cdv};
            #endif
            #ifdef USE_IXOR
            arr[tot++]=code{IXOR,ccv,cdv};
            #endif
            #ifdef USE_IADD
            arr[tot++]=code{IADD,ccv,cdv};
            #endif
        }
    }
    //ISAR&ISAL
    for(int i=0;i<salConstLen;i++)
    {
        int vmx=salConst[i];
        arr[tot++]=code{ISAL,vmx>>8,vmx&255};
    }
    for(int i=0;i<constIntListLen;i++)
    {
        int vi=constIntList[i];
        if(vi==0)   continue;
        for(int j=0;j<storageSize;j++)
        {
            int sj=j|storagePrefix;
            #ifdef USE_ISAR
            arr[tot++]=code{ISAR,vi,sj};
            #endif
            #ifdef USE_ISAL
            arr[tot++]=code{ISAL,vi,sj};
            #endif
        }
    }
    for(int i=0;i<storageSize;i++)
    {
        int si=i|storagePrefix;
        for(int j=0;j<constIntListLen;j++)
        {
            int vj=constIntList[j];
            if((vj&31)==0)   continue;
            #ifdef USE_ISAR
            arr[tot++]=code{ISAR,si,vj};
            #endif
            #ifdef USE_ISAL
            arr[tot++]=code{ISAL,si,vj};
            #endif
        }
        for(int j=0;j<storageSize;j++)
        {
            int sj=j|storagePrefix;
            #ifdef USE_ISAR
            arr[tot++]=code{ISAR,si,sj};
            #endif
            #ifdef USE_ISAL
            arr[tot++]=code{ISAL,si,sj};
            #endif
        }
    }
    return tot;
}
const int MAX_CODES=1000;

struct runtime
{
    int storage[MAX_OPS+INPUT_SIZE];
    int stop;
    runtime()
    {
        stop=0;
    }
    runtime(input_t input)
    {
        stop=INPUT_SIZE;
        for(int i=0;i<INPUT_SIZE;i++)
            storage[i]=input.s[i];
    }
    void spush(int x)
    {
        storage[stop++]=x;
    }
    int getValue(int x)
    {
        int spx=(x^storagePrefix);
        if(spx<MAX_OPS+INPUT_SIZE && spx>=0) return storage[x^storagePrefix];
        return x;
    }
};

bool runCode(runtime& state,code nowcode)
{
    int a,b;
    switch (nowcode.opcode)
    {
        case INOT:
        a=state.getValue(nowcode.val1);
        state.spush(~a);
        break;
        case BNOT:
        a=state.getValue(nowcode.val1);
        state.spush(!a);
        break;
        case IAND:
        a=state.getValue(nowcode.val1);
        b=state.getValue(nowcode.val2);
        state.spush(a&b);
        break;
        case IOR:
        a=state.getValue(nowcode.val1);
        b=state.getValue(nowcode.val2);
        state.spush(a|b);
        break;
        case IXOR:
        a=state.getValue(nowcode.val1);
        b=state.getValue(nowcode.val2);
        state.spush(a^b);
        break;
        case IADD:
        a=state.getValue(nowcode.val1);
        b=state.getValue(nowcode.val2);
        state.spush(a+b);
        break;
        case ISAR:
        a=state.getValue(nowcode.val1);
        b=state.getValue(nowcode.val2);
        state.spush(a>>b);
        break;
        case ISAL:
        a=state.getValue(nowcode.val1);
        b=state.getValue(nowcode.val2);
        state.spush(a<<b);
        break;
        default:
        cerr<<"ERROR"<<endl;
        cerr<<nowcode.opcode<<endl;
        return 0;
    }
    return 1;
}

bool runCode(runtime& state,code nowcode,int rflag)
{
    int a,b;
    switch (nowcode.opcode)
    {
        case INOT:
        a=state.getValue(nowcode.val1);
        state.spush(~a);
        break;
        case BNOT:
        a=state.getValue(nowcode.val1);
        state.spush(!a);
        break;
        case IAND:
        a=state.getValue(nowcode.val1);
        b=state.getValue(nowcode.val2);
        state.spush(a&b);
        break;
        case IOR:
        a=state.getValue(nowcode.val1);
        b=state.getValue(nowcode.val2);
        state.spush(a|b);
        break;
        case IXOR:
        a=state.getValue(nowcode.val1);
        b=state.getValue(nowcode.val2);
        state.spush(a^b);
        break;
        case IADD:
        a=state.getValue(nowcode.val1);
        b=state.getValue(nowcode.val2);
        state.spush(a+b);
        break;
        case ISAR:
        a=state.getValue(nowcode.val1);
        b=state.getValue(nowcode.val2);
        state.spush(a>>b);
        break;
        case ISAL:
        a=state.getValue(nowcode.val1);
        b=state.getValue(nowcode.val2);
        state.spush(a<<b);
        break;
        default:
        cerr<<"ERROR"<<endl;
        cerr<<nowcode.opcode<<endl;
        return 0;
    }
    return 1;
}

bool checkAll(code* codes,int codel)
{
    for(int i=0;i<MAX_TEST_SAMPLES;i++)
    {
        input_t ni=getSample(i);
        int no=rightFunction(ni);
        runtime nowrt(ni);
        for(int j=0;j<codel;j++)
        {
            bool g=runCode(nowrt,codes[j]);
            if(!g)  return 0;
            //cout<<codes[j].opcode<<' '<<codes[j].val1<<' '<<codes[j].val2<<endl;
            //cout<<nowrt.stop<<' '<<nowrt.storage[nowrt.stop-1]<<endl;
        }
        if(nowrt.stop<1)    return 0;
        int ans=nowrt.storage[nowrt.stop-1];
        //cout<<ans<<' '<<no<<endl;
        if(ans!=no) return 0;
    }
    return 1;
}

int countCOps(code* codes,int codel)
{
    int cnt=0;
    for(int i=0;i<codel;i++)
        if(codes[i].opcode>=INOT && codes[i].opcode<=BNOT)  cnt++;
    return cnt;
}

struct runtimechecker
{
    runtime s[MAX_CHECK_SAMPLES];
    runtimechecker()
    {
        for(int i=0;i<MAX_CHECK_SAMPLES;i++)
            s[i]=runtime(getSample(i));
    }
    runtimechecker(input_t* inps)
    {
        for(int i=0;i<MAX_CHECK_SAMPLES;i++)
            s[i]=runtime(inps[i]);
    }
    bool runCode(code nowcode)
    {
        bool flag=(::runCode(s[0],nowcode,1));
        for(int i=1;i<MAX_CHECK_SAMPLES && flag;i++)
            flag&=(::runCode(s[i],nowcode));
        return flag;
    }
};

struct message
{
    long type;
};

void sig_child(int sn){
    pid_t pid; 
    int status; 
    while((pid=waitpid(-1,&status,WNOHANG))>0){}
    return; 
}

int mid;
int ranss[MAX_CHECK_SAMPLES];
code path[MAX_OPS];
void dfs(runtimechecker& nows,int depth)
{
    //cout<<depth<<endl;
    if(depth>=MAX_OPS)   return;
    //check right
    bool flag=1;
    for(int i=0;i<MAX_CHECK_SAMPLES;i++)
    {
        if(nows.s[i].stop<1)
        {
            flag=0;
            break;
        }
        runtime& rt=nows.s[i];
        if(rt.storage[rt.stop-1]!=ranss[i])
        {
            flag=0;
            break;
        }
    }
    if(flag)
    {
        if(checkAll(path,depth))
        {
            cout<<"FOUND "<<countCOps(path,depth)<<endl;
            for(int i=0;i<depth;i++)
                cout<<path[i].opcode<<' '<<path[i].val1<<' '<<path[i].val2<<endl;
            return;
        }
    }
    code nexs[MAX_CODES];
    int slen=nows.s[0].stop;
    int rlen=getCodes(nexs,slen);
    message tmp;
    for(int i=0;i<rlen;i++)
    {
        key_t mpid=1;
        if(depth<FORKD)
        {
            int flg=msgrcv(mid,&tmp,0,0,IPC_NOWAIT);
            if(flg>=0)
            {
                signal(SIGCHLD,sig_child);
                mpid=fork();
                if(mpid!=0) continue;
            }
        }
        runtimechecker nt=nows;
        bool rtv=nt.runCode(nexs[i]);
        path[depth]=nexs[i];
        if(rtv)
            dfs(nt,depth+1);
        if(mpid==0)
        {
            msgsnd(mid,&tmp,0,0);
            _exit(0);
        }
    }
    return;
}

void init()
{
    int jb[255][50];
    memset(jb,0,sizeof(jb));
    for(int i=0;i<constIntListLen;i++)
    {
        int vi=constIntList[i];
        if(vi==0)   continue;
        for(int j=0;j<constIntListLen;j++)
        {
            int vj=constIntList[j];
            if((vj&31)==0 || vj>=32)    continue;
            int xa=vi;
            int xb=vj;
            while((xa&1)==0)
            {
                xa>>=1;
                xb++;
            }
            if(jb[xa][xb])  continue;
            jb[xa][xb]=1;
            salConst[salConstLen++]=((vi<<8)|vj);
        }
    }
}

void search()
{
    int pc=0;
    mid=msgget(0,IPC_CREAT | 0666);
    message tmp;
    tmp.type=1;
//    cout<<mid<<endl;
    for(int i=1;i<FORKC;i++)
    {
        int st=msgsnd(mid,&tmp,0,0);
        if(st!=0)
        {
            cout<<st<<endl;
            cout<<errno<<endl;
            cout<<strerror(errno)<<endl;
        }
    }
    runtimechecker inst;
    for(int i=0;i<MAX_CHECK_SAMPLES;i++)
        ranss[i]=rightFunction(getSample(i));
    dfs(inst,0);
}

void test()
{
    code testcodes[MAX_CODES];
    int len=getCodes(testcodes,5);
    cout<<len<<endl;
    //for(int i=0;i<len;i++)
    //    cout<<testcodes[i].opcode<<' '<<testcodes[i].val1<<' '<<testcodes[i].val2<<endl;
    // code mo4[4]={code{IADD,27,storagePrefix},code{ISAR,1|storagePrefix,2},code{IAND,2|storagePrefix,storagePrefix},code{IADD,3|storagePrefix,1}};
    // cout<<checkAll(mo4,4)<<endl;
    // code mo4w[5]={code{IADD,28,storagePrefix},code{ISAR,1|storagePrefix,2},code{IAND,2|storagePrefix,storagePrefix},code{IADD,3|storagePrefix,1}};
    // cout<<checkAll(mo4w,4)<<endl;
    search();
}
int main()
{
    init();
    test();
    //search();
	return 0;
}
