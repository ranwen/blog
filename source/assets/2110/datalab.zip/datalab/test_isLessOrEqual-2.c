int test_isLessOrEqual(int x, int y)
{
  return x <= y;
}
