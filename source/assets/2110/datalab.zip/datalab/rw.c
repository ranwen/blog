#include<stdio.h>
#include<math.h>

#include "bits.c"
#include "tests.c"

int reverse(int x) {
    int a=((x&0x55555555)<<1)|((x&0xaaaaaaaa)>>1);
    int b=((a&0x33333333)<<2)|((a&0xcccccccc)>>2);
    int c=((b&0x0f0f0f0f)<<4)|((b&0xf0f0f0f0)>>4);
    int d=((c&0x00ff00ff)<<8)|((c&0xff00ff00)>>8);
    return (d>>16)&0xffff;
}

int test_reverse(int x)
{
    int ans=0;
    for(int i=0;i<16;i++)
        ans|=((x>>(31-i))&1)<<i;
    return ans;
}

int main()
{
    for(int i=-200;i<200;i++)
    {
        unsigned a=float_pwr2(i);
        unsigned b=test_float_pwr2(i);
        if(a!=b)
        {
            printf("%d %d %d\n",i,a,b);
        }
    }
    for(int i=-200;i<200;i++)
    {
        int x=521;
        float v=x*pow(2,i);
        unsigned vv=f2u(v);
	if(i==199)	vv=1308622848;
        int a=float_f2i(vv);
        int b=test_float_f2i(vv);
	if(a!=b)
            printf("%d %d %d\n",vv,a,b);
    }
    for(int i=0;i<32;i++)
    {
        int v=1<<i;
        unsigned a=reverse(v);
        unsigned b=test_reverse(v);
        if(a!=b)
        {
            printf("%d %d %d\n",v,a,b);
        }
    }
    return 0;
}
