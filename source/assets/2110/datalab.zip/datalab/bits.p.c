#line 177 "bits.c"
int bitNot(int x) {
    int c=(1<<31)>>31;
#line 31 "<command-line>"
#line 179 "bits.c"
  return x^c;
}
#line 188
int bitXor(int x, int y) {
  return (~(x&y) & ~(~x&~y));
}
#line 198
int allOddBits(int x) {
    int a=0xaa;
    int b=a|(a<<8);
    int c=b|(b<<16);
  return !((x&c)^c);
}
#line 212
int rotateRight(int x, int n) {
    int d=(~0)^(1<<31);
    int jianv=31^n;
    int jjv=jianv+1;
    int msk=d>>jianv;
    int hmsk=msk<<jjv;

  return ((x>>n)&~hmsk)|((x&msk)<<jjv);
}
#line 235
int palindrome(int x) {
    int a=((x&0x55555555)<<1)|((x&0xaaaaaaaa)>>1);
    int b=((a&0x33333333)<<2)|((a&0xcccccccc)>>2);
    int c=((b&0x0f0f0f0f)<<4)|((b&0xf0f0f0f0)>>4);
    int d=((c&0x00ff00ff)<<8)|((c&0xff00ff00)>>8);
    int nlb=d&0xffff;
    int ohb=(x>>16)&0xffff;
  return !(nlb^ohb);
}
#line 254
int countConsecutive1(int x) {
    int ccv=x^(x<<1);
    int pp29=(7<<29);
    int cv1=0x11;
    int cv2=cv1|(cv1<<8);
    int cv1p=cv2|(cv2<<16);
    int cv2p=cv1p<<1;
    int cv4p=cv1p<<2;
    int cv8p=cv1p<<3;
    int va1=(ccv&cv1p)+((ccv&cv2p)>>1)+((ccv&cv4p)>>2)+((((ccv&cv8p)>>3)|pp29)^pp29);

    int va2=(va1&7)+((va1>>4)&7)+((va1>>8)&7)+((va1>>12)&7)+((va1>>16)&7)+((va1>>20)&7)+((va1>>24)&7)+((va1>>28)&7);
#line 269
    return (va2+1)>>1;
}
#line 278
int counter1To5(int x) {
    int ret=x+1;
    int f5=(!((x+3)&7))<<31>>31;
    return (ret&~f5)|(1&f5);
}
#line 292
int fullSub(int x, int y) {
    int yb=~y;

    int sm1=x^yb;
    int jw1=((x&yb)<<1)^1;

    int sm2=sm1^jw1;
    int jw2=(sm1&jw1)<<1;

    int sm3=sm2^jw2;
    int jw3=(sm2&jw2)<<1;

    int sm4=sm3^jw3;
    int jw4=(sm3&jw3)<<1;
    return (sm4^jw4)&0xf;
}
#line 315
int isLessOrEqual(int x, int y) {
    int difh=x^y;
    int flgb1=difh&x;
    int flgb0=difh&y;
    int cha=~(y+(~x+1));
#line 324
    int res=((cha&~flgb0&~flgb1)|(flgb1))&(~flgb0);
    return (res>>31)&1;
}
#line 335
int sm2tc(int x) {
    int negmask=x>>31;
  return (x&(~negmask))|(((~(x^(1<<31)))+1)&negmask);
}
#line 349
int satAdd(int x, int y) {
    int ret=x+y;
    int xhb=x>>31;
    int yhb=y>>31;
    int rhb=ret>>31;
    int eqv=(~(xhb^yhb));
    int maxo=eqv&rhb&~xhb;
    int mino=eqv&~rhb&xhb;
    int fff=(1<<31);

    return (ret&~(maxo|mino))|(~fff&maxo)|(fff&mino);
}
#line 371
int trueFiveEighths(int x)
{
    int a=x>>1;
    int b=x>>3;
    int c=x&(x>>2)&1;
    int lb=(x&7);
    int d=(x>>31)&!!lb;
    return a+b+c+d;
}
#line 391
unsigned float_twice(unsigned uf) {


    unsigned expv=uf&2139095040;
    unsigned mv=uf&8388607;
    unsigned rtv=uf^mv^(mv<<1);
    if (expv==2139095040) return uf;
    if (expv) 
    {
        if (expv!=2130706432) return uf^expv^(expv+8388608);
        return (uf&0x80000000)+2139095040;
    }
    return rtv;
}
#line 416
unsigned float_half(unsigned uf) {
    unsigned expv=uf&2139095040;
    unsigned mv=uf&8388607;

    unsigned hfv1=(mv>>1);
    unsigned hfv=hfv1+((hfv1&mv)&1);
    unsigned rtv=uf^mv^hfv;
    if (expv==2139095040) return uf;
    if (expv) 
    {
        if (expv!=8388608) return uf^expv^(expv-8388608);
        return (uf&0x80000000)+hfv+4194304;
    }
    return rtv;
}
#line 443
int float_f2i(unsigned uf) {
    int sf=uf;
    unsigned expv=(uf>>23)&255;
    unsigned mv=uf&8388607;

    unsigned sv=sf<0;
    unsigned basev=(8388608+mv);
    int flag=sv?1:1;
    int ssv=expv>=150?(basev<<(expv-150)):(basev>>(150-expv));

    if (expv<127) return 0;
    if (expv>=158) return 0x80000000u;

    return flag*ssv;
}
#line 471
unsigned float_pwr2(int x) {
    if (x<-149) return 0;
    if (x<-126) return 1<<(149+x);
    if (x>127) return 2139095040;
    return (127+x)<<23;
}
