TABC=0
def rprint(st):
    print(' '*TABC*4,end='')
    print(st)

rprint("int alu0=0,alu1=0,alu2=0;")
rprint("int reg0=0,reg1=0,reg2=0,reg3=0,reg4=0,reg5=0,reg6=0,reg7=0;")
rprint("int bw"+"=0,bw".join(list(map(str,range(32))))+"=0;")
#rprint("int cw"+"=0,cw".join(list(map(str,range(32))))+"=0;")
rprint("int nowl=1;")
rprint("int expv=0,sv=0;")

#reg0 is borrow bit

def gen_add_begin(adw):
    pd=("reg1=0;if(bw%d){if(cw%d){if(reg2){reg1=1;}else{reg2=1;}}\
else{if(reg2){}else{reg1=1;}}}\
else{if(cw%d){if(reg2){}else{reg1=1;}}\
else{if(reg2){reg1=1;reg2=0;}else{}}}"%(adw,adw,adw))+\
    ("alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0x%x;}"%(0xffffffff^(2**adw)))
    if adw<1:
        return pd
    pd2=("reg1=0;if(bw%d){if(reg2){}else{reg1=1;}}\
else{if(reg2){reg1=1;reg2=0;}else{}}"%adw)+("alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0x%x;}"%(0xffffffff^(2**adw)))
    if adw<23:
        return pd2
    return pd

def show_before():
    global TABC
    rprint("switch(nowl)")
    rprint('{')
    TABC+=1
    rprint("case 1: alu0=uf;alu1=0x80000000;break;")
    rprint("case 2: alu1=0x7f800000;break;")
    for i in range(23):
        rprint("case %d: alu1=0x%x;break;"%(3+i,2**i))
    for i in range(32):
        rprint("case %d: %s break;"%(i+26, ("alu0=alu2;if(bw%d){alu1=0xffffffff;}else{alu1=0x%x;}"%(i,0xffffffff^(2**i))) ))
    TABC-=1
    rprint('}')

def hugecase():
    txt=""
    for expv in range(0,127):
        txt=txt+"case 0x%x: "%((expv)<<23)
    txt=txt+"return 0;"
    rprint(txt)
    txt=""
    for expv in range(158,256):
        txt=txt+"case 0x%x: "%((expv)<<23)
    txt=txt+"return 0x80000000u;"
    rprint(txt)
    # for expv in range(127,158):
    #     cdl="rexpv=%d;"%expv
    #     rprint("case 0x%x: %s break;"%((expv)<<23,cdl))

def show_after():
    global TABC
    rprint("switch(nowl)")
    rprint('{')
    TABC+=1
    rprint("case 1: sv=alu2;nowl=2;break;")
    rprint("case 2: expv=alu2;")
    rprint("switch(expv)")
    rprint("{")
    TABC+=1
    hugecase()

    TABC-=1
    rprint('} nowl=3;break;')
    for i in range(22):
        rprint("case %d: bw%d=alu2;nowl=%d;break;"%(3+i,i,4+i))
    rprint("case %d: bw%d=alu2;nowl=%d;bw23=1;"%(3+22,22,4+22))
    # rprint("switch(expv)")
    # rprint('{')
    # TABC+=1
    # for expv in range(127,158):
    #     cdl="case 0x%x: "%(expv<<23)
    #     if expv>=150:
    #         dtv=expv-150
    #         for i in range(24):
    #             cdl=cdl+"cw%d=bw%d;"%(i+dtv,i)
    #     else:
    #         dtv=150-expv
    #         for i in range(24):
    #             if i-dtv<0:
    #                 continue
    #             cdl=cdl+"cw%d=bw%d;"%(i-dtv,i)
    #     rprint(cdl+"break;")
    # TABC-=1
    # rprint('}')
    #sar
    for bi in range(5):
        rprint("switch(expv)")
        rprint('{')
        TABC+=1
        cdl=""
        for expv in range(127,151):
            dtv=150-expv
            if ((dtv>>bi)&1)==1:
                cdl+="case 0x%x: "%(expv<<23)
        rprint(cdl)
        cdl=""
        pdv=2**bi
        for i in range(pdv,24):
            cdl=cdl+"bw%d=bw%d;"%(i-pdv,i)
        for i in range(0,pdv):
            cdl=cdl+"bw%d=0;"%(24-pdv+i)
        rprint(cdl)
        TABC-=1
        rprint('}')
    #sal
    for bi in range(3):
        rprint("switch(expv)")
        rprint('{')
        TABC+=1
        cdl=""
        for expv in range(151,158):
            dtv=expv-150
            if ((dtv>>bi)&1)==1:
                cdl+="case 0x%x: "%(expv<<23)
        rprint(cdl)
        cdl=""
        pdv=2**bi
        bgv=30
        bgv=min(bgv,22+pdv+pdv)
        for i in range(bgv,pdv-1,-1):
            cdl=cdl+"bw%d=bw%d;"%(i,i-pdv)
        for i in range(0,pdv):
            cdl=cdl+"bw%d=0;"%i
        rprint(cdl)
        TABC-=1
        rprint('}')
    #neg
    rprint('if(sv)')
    rprint('{')
    TABC+=1
    for i in range(31):
        cl='if(bw%d){if(reg0){bw%d=0;}else{reg0=1;}}\
else{if(reg0){bw%d=1;}else{}}'%(i,i,i)
        rprint(cl)
    rprint('bw31=1;')
    TABC-=1
    rprint('}')
    #end
    rprint("alu2=0xffffffff;break;"%())
    for i in range(31):
        rprint("case %d: nowl=%d;break;"%(26+i,27+i))
    rprint("case %d: nowl=%d;reg7=alu2;break;"%(26+31,0))
    TABC-=1
    rprint('}')

rprint("while(nowl)")
rprint("{")
TABC+=1

show_before()
rprint("alu2=alu0&alu1;")
show_after()

TABC-=1
rprint("}")
#rprint("return sv?-reg7:reg7;")
rprint('return reg7;')