/* 
 * CS:APP Data Lab 
 * 
 * <Please put your name and userid here>
 * 
 * bits.c - Source file with your solutions to the Lab.
 *          This is the file you will hand in to your instructor.
 *
 * WARNING: Do not include the <stdio.h> header; it confuses the dlc
 * compiler. You can still use printf for debugging without including
 * <stdio.h>, although you might get a compiler warning. In general,
 * it's not good practice to ignore compiler warnings, but in this
 * case it's OK.  
 */

#if 0
/*
 * Instructions to Students:
 *
 * STEP 1: Read the following instructions carefully.
 */

You will provide your solution to the Data Lab by
editing the collection of functions in this source file.

INTEGER CODING RULES:
 
  Replace the "return" statement in each function with one
  or more lines of C code that implements the function. Your code 
  must conform to the following style:
 
  int Funct(arg1, arg2, ...) {
      /* brief description of how your implementation works */
      int var1 = Expr1;
      ...
      int varM = ExprM;

      varJ = ExprJ;
      ...
      varN = ExprN;
      return ExprR;
  }

  Each "Expr" is an expression using ONLY the following:
  1. Integer constants 0 through 255 (0xFF), inclusive. You are
      not allowed to use big constants such as 0xffffffff.
  2. Function arguments and local variables (no global variables).
  3. Unary integer operations ! ~
  4. Binary integer operations & ^ | + << >>
    
  Some of the problems restrict the set of allowed operators even further.
  Each "Expr" may consist of multiple operators. You are not restricted to
  one operator per line.

  You are expressly forbidden to:
  1. Use any control constructs such as if, do, while, for, switch, etc.
  2. Define or use any macros.
  3. Define any additional functions in this file.
  4. Call any functions.
  5. Use any other operations, such as &&, ||, -, or ?:
  6. Use any form of casting.
  7. Use any data type other than int.  This implies that you
     cannot use arrays, structs, or unions.

 
  You may assume that your machine:
  1. Uses 2s complement, 32-bit representations of integers.
  2. Performs right shifts arithmetically.
  3. Has unpredictable behavior when shifting an integer by more
     than the word size.

EXAMPLES OF ACCEPTABLE CODING STYLE:
  /*
   * pow2plus1 - returns 2^x + 1, where 0 <= x <= 31
   */
  int pow2plus1(int x) {
     /* exploit ability of shifts to compute powers of 2 */
     return (1 << x) + 1;
  }

  /*
   * pow2plus4 - returns 2^x + 4, where 0 <= x <= 31
   */
  int pow2plus4(int x) {
     /* exploit ability of shifts to compute powers of 2 */
     int result = (1 << x);
     result += 4;
     return result;
  }

FLOATING POINT CODING RULES

For the problems that require you to implent floating-point operations,
the coding rules are less strict.  You are allowed to use looping and
conditional control.  You are allowed to use both ints and unsigneds.
You can use arbitrary integer and unsigned constants.

You are expressly forbidden to:
  1. Define or use any macros.
  2. Define any additional functions in this file.
  3. Call any functions.
  4. Use any form of casting.
  5. Use any data type other than int or unsigned.  This means that you
     cannot use arrays, structs, or unions.
  6. Use any floating point data types, operations, or constants.


NOTES:
  1. Use the dlc (data lab checker) compiler (described in the handout) to 
     check the legality of your solutions.
  2. Each function has a maximum number of operators (! ~ & ^ | + << >>)
     that you are allowed to use for your implementation of the function. 
     The max operator count is checked by dlc. Note that '=' is not 
     counted; you may use as many of these as you want without penalty.
  3. Use the btest test harness to check your functions for correctness.
  4. Use the BDD checker to formally verify your functions
  5. The maximum number of ops for each function is given in the
     header comment for each function. If there are any inconsistencies 
     between the maximum ops in the writeup and in this file, consider
     this file the authoritative source.

/*
 * STEP 2: Modify the following functions according the coding rules.
 * 
 *   IMPORTANT. TO AVOID GRADING SURPRISES:
 *   1. Use the dlc compiler to check that your solutions conform
 *      to the coding rules.
 *   2. Use the BDD checker to formally verify that your solutions produce 
 *      the correct answers.
 */


#endif
/* Copyright (C) 1991-2018 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, see
   <http://www.gnu.org/licenses/>.  */
/* This header is separate from features.h so that the compiler can
   include it implicitly at the start of every compilation.  It must
   not itself include <features.h> or any other header that includes
   <features.h> because the implicit include comes before any feature
   test macros that may be defined in a source file before it first
   explicitly includes a system header.  GCC knows the name of this
   header in order to preinclude it.  */
/* glibc's intent is to support the IEC 559 math functionality, real
   and complex.  If the GCC (4.9 and later) predefined macros
   specifying compiler intent are available, use them to determine
   whether the overall intent is to support these features; otherwise,
   presume an older compiler has intent to support these features and
   define these macros by default.  */
/* wchar_t uses Unicode 10.0.0.  Version 10.0 of the Unicode Standard is
   synchronized with ISO/IEC 10646:2017, fifth edition, plus
   the following additions from Amendment 1 to the fifth edition:
   - 56 emoji characters
   - 285 hentaigana
   - 3 additional Zanabazar Square characters */
/* We do not support C11 <threads.h>.  */
/* 
 * bitNot - ~x without using ~
 *   Example: bitNot(0) = 0xffffffff
 *   Legal ops: ! & ^ | + << >>
 *   Max ops: 12
 *   Rating: 1
 */
int bitNot(int x) {
    int c=(1<<31)>>31;//use SAR to make c=0xffffffff then xor with x
  return x^c;
}
/* 
 * bitXor - x^y using only ~ and & 
 *   Example: bitXor(4, 5) = 1
 *   Legal ops: ~ &
 *   Max ops: 14
 *   Rating: 1
 */
int bitXor(int x, int y) {
  return (~(x&y) & ~(~x&~y));//be true when 01 or 10, means (x OR y) and (x AND y) =1
}
/* 
 * allOddBits - return 1 if all odd-numbered bits in word set to 1
 *   Examples allOddBits(0xFFFFFFFD) = 0, allOddBits(0xAAAAAAAA) = 1
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 12
 *   Rating: 2
 */
int allOddBits(int x) {
    int a=0xaa;
    int b=a|(a<<8);
    int c=b|(b<<16);//c=0xaaaaaaaa
  return !((x&c)^c);//get all odd bits then xor with c. be 0 when all odd bits is 1
}
/* 
 * rotateRight - Rotate x to the right by n
 *   Can assume that 0 <= n <= 31
 *   Examples: rotateRight(0x87654321,4) = 0x18765432
 *   Legal ops: ~ & ^ | + << >>
 *   Max ops: 25
 *   Rating: 3 
 */
int rotateRight(int x, int n) {
    // Version 1  9ops
    // int jianv=31^n;//equal to 31-n
    // int jjv=jianv+1;//equal to 32-n
    // int hmsk=(~0)<<jjv;//mask while high n bits is 1, where the moving bits place use (x<<32)==(x<<0)
    // return ((x>>n)&~hmsk)|(x<<jjv);//((x>>n)&~hmsk): move right and only keep (32-n) bits; (x<<jjv): move left

    // Version 2  7ops
    int jianv=31^n;//equal to 31-n
    // we can return ((x>>>n))^(x<<(31-n)<<1) when >>> means SHR
    // use <<(31-n)<<1 instead of 0 to construct 0 when n=0
    // and we can use (x>>n)^(x>>31<<(31-n)<<1) as SHR
    // combine and then we get it
    return ((x>>n))^((x^(x>>31))<<jianv<<1);
}
/* 
 * palindrome - return 1 if x is palindrome in binary form,
 *   return 0 otherwise
 *   A number is palindrome if it is the same when reversed
 *   YOU MAY USE BIG CONST IN THIS PROBLEM, LIKE 0xFFFF0000
 *   YOU MAY USE BIG CONST IN THIS PROBLEM, LIKE 0xFFFF0000
 *   YOU MAY USE BIG CONST IN THIS PROBLEM, LIKE 0xFFFF0000
 *   Example: palindrome(0xff0000ff) = 1,
 *            palindrome(0xff00ff00) = 0
 *   Legal ops: ~ ! | ^ & << >> +
 *   Max ops: 40
 *   Rating: 4

 */
int palindrome(int x) {
    // Version 1  24ops
    // try to reverse low 16 bits of x
    // we can swap groups of sequences in a row like b=((a&0x0011001100110011)<<2)|((a&0x1100110011001100)>>2);
    // then swap for 4 times then the bits are reversed
    // int a=((x&0x00005555)<<1)|((x&0x0000aaaa)>>1);
    // int b=((a&0x00003333)<<2)|((a&0x0000cccc)>>2);
    // int c=((b&0x00000f0f)<<4)|((b&0x0000f0f0)>>4);
    // int d=((c&0x000000ff)<<8)|((c&0x0000ff00)>>8);
    // int nlb=d;
    // int ohb=(x>>16);
    // return !((nlb^ohb)&0xffff); //check x's high 16 bits and d's low 16 bits

    // Version 2  20ops
    // notice that we don't need to 'swap', while we can move all the bits higher
    int a=((x&0x00005555)<<2)|((x&0x0000aaaa));//so we can recude one SAR,but low 1 bit is null
    int b=((a&0x00006666)<<4)|((a&0x00019998));//low 3 bits is null
    int c=((b&0x00007878)<<8)|((b&0x00078780));//low 7 bits is null
    int d=((c)<<16)|((c&0x007f8000));//low 15 bits is null
    int nlb=d;
    int ohb=(x>>1);//we need to compare d>>15 and x>>16, but we can compare d and x>>1 instead of that
    return !((nlb^ohb)&0x7fff8000);//notice that we only need middle 16 bits, the mask is 0x7fff8000
}
/*
 * countConsecutive1 - return the number of consecutive 1‘s
 *   in the binary form of x
 *   Examples: countConsecutive1(0xff00ff00) = 2,
 *             countConsecutive1(0xf070f070) = 4,
 *             countConsecutive1(0b00101010001111110101110101110101) = 10
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 50
 *   Rating: 4
 */
int countConsecutive1(int x) {
    // if we want to calc popcount of binary (abcdxyzw) then we can calc a000x+b000y+c000z+d000w
    // then we get %%%0&&&, while %%%=a+b+c+d, &&&=x+y+z+w, so we can just add them and get ans
    // use this way in 32bits number
    int ccv=x&(~(x<<1));//we want to know how many "10" in x, and we assume the -1 bit is 0, so we calc it and then popcount to get ans
    int cv1=0x11;
    int cv2=cv1|(cv1<<8);
    int cv1p=cv2|(cv2<<16);//0x11111111 to extract number like a000x
    int va1=(ccv&cv1p)+((ccv>>1)&cv1p)+((ccv>>2)&cv1p)+((ccv>>3)&cv1p);//calc the number like %%%0&&&, it has 8 parts
    int va21=va1+(va1>>16);
    int va2=va21+(va21>>8);//we can use last step similarly, add all %%%0&&& together
    // because %%%<=100, and sum will not exceed to 16 so we can add 4 of them and won't exceed to 1100, no carry bit
    int va3=(((va2&15)+((va2>>4)&15)));//calc the sum. two of them from va2. answer<=16
    return va3;
}
/* 
 * counter1To5 - return 1 + x if x < 5, return 1 otherwise, we ensure that 1<=x<=5
 *   Examples counter1To5(2) = 3,  counter1To5(5) = 1
 *   Legal ops: ~ & ! | + << >>
 *   Max ops: 15
 *   Rating: 2
 */
int counter1To5(int x) {
    // Version 1  8ops
    // int ret=x+2;
    // int f5=(x+3)<<28>>31;//check x=5, the only number x+3>=8,so we use 3-lowerest bit to check it. f5=(x==5?0xffffffff:0)
    // return (ret&~f5)|(1&f5);//use mask to make logic decision

    // Version 2  7ops
    // int ret=x+2;
    // int f5=(x+3)>>3;//check x=5,f5=(x==5?1:0)
    // f5=f5|(f5<<2);//f5=(x==5?5:0)
    // return ret+(~f5);//ret-f5-1

    // Version 3  6ops
    // int tv=x+7;//tv'=x+7 and its low 3 bits is tv=x-1 which in[0,4] then we need to return tv==4?1:tv+2, or ((tv&3)==0)?2-(tv==4):(tv&3)+2
    // int tv=x+~0;
    // return (tv&3)+2+(tv<<29>>31);//(tv<<29>>31)=(tv==4)?-1:0

    // Version 4  4ops
    // find by my cpp VM Searcher
    // the prototype is below. will publish a full version of all task after ddl in some website(?)
    // cost about 20min running on hpc in pku with 1t
    // cost about 3.5min running on my R7-5800H with 16t(fork version)
    // the expression is easy to understand
    // return (((27+x)>>2)&x)+1;
    /* original output
    0 1   PUSH 1 
    0 2   PUSH 2
    0 27  PUSH 27
    16 0  LOAD 0
    48 0  IADD
    64 0  ISAR
    16 0  LOAD 0
    33 0  IAND
    48 0  IADD
    */
   // return 1+(x>>((x<<2)&x))
   // the answer also find by computer and hard to explain XD

   // Version 5  3ops
   // also find by computer. I run program with all magic number and check func (x==5)?0:x
   return 1+((91>>x)&x);
}
/*
 * fullSub - 4-bits sub using bit-wise operations only.
 *   (0 <= x, y < 16) 
 *   Example: fullSub(12, 7) = 0x5,
 *            fullSub(7, 8) = 0xf,
 *   Legal ops: ~ | ^ & << >>
 *   Max ops: 35
 *   Rating: 2
 */
int fullSub(int x, int y) {
    // Version 1  16ops
    // add x and (~y)+1 then return low 4 bits
    // int yb=~y;
    // int sm1=x^yb;//add x and ~y without carry bit
    // int jw1=((x&yb)<<1)^1;//calc carry bit, the ^1 is from (~y)+1
    // int sm2=sm1^jw1;//same as last step
    // int jw2=(sm1&jw1)<<1;
    // int sm3=sm2^jw2;
    // int jw3=(sm2&jw2)<<1;
    // int sm4=sm3^jw3;
    // int jw4=(sm3&jw3)<<1;//at most 4 times carry
    // return (sm4^jw4)&0xf;//add carry bit then return

    // Version 2  14ops
    // calc x-y directly
    // int sm1=x^y;//sub without borrow
    // int tw1=((~x)&y)<<1;//calc borrow when x=0 and y=1
    // int sm2=sm1^tw1;
    // int tw2=((~sm1)&tw1)<<1;
    // int sm3=sm2^tw2;
    // int tw3=((~sm2)&tw2)<<1;//as most 3 times borrow
    // return (sm3^tw3)&0xf;

    // Version 3  11ops
    // ~(a^b)=(~a^b)
    int sm1=x^y;
    int tw1=(sm1&y)<<1;//calc borrow in another way
    int sm2=sm1^tw1;
    int tw2=(sm2&tw1)<<1;
    int sm3=sm2^tw2;
    int tw3=(sm3&tw2)<<1;
    return ((sm3^tw3))&0xf;
}
/* 
 * isLessOrEqual - if x <= y  then return 1, else return 0 
 *   Example: isLessOrEqual(4,5) = 1.
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 24
 *   Rating: 3
 */
int isLessOrEqual(int x, int y) {
    // Version 1  8ops
    // int difh=x^y;//check different sign, to avoid sub overflow
    // old version, use De Morgan's law to reduce ops
    // int cha=~(y+(~x+1));//calc y-x, because return 1 when y==x, like y>x which has highest bit 0
    // int res=(cha&(~difh))|(x&difh);//return sub result when same sign, else return x

    // int cha=(x+(~y));//calc x-y-1, because return 1 when y==x, like y>x which has highest bit 0
    // int res=(cha)^((x^cha)&difh);//return sub result when same sign, else return x
    // return (res>>31)&1;//return highest bit

    // Version 3  7ops
    int fg=(x^y)>>31;
    return ((x+~(y|fg))>>31)&1;
}
/* 
 * sm2tc - Convert from sign-magnitude to two's complement
 *   where the MSB is the sign bit
 *   Example: sm2tc(0x80000005) = -5.
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 15
 *   Rating: 4
 */
int sm2tc(int x) {
    // Version 1  9ops
    // int negmask=x>>31;//0xffffffff when negative, 0 else
    // return (x&(~negmask))|(((~(x^(1<<31)))+1)&negmask);//simplily use mask

    // Version 2  9ops
    // int negmask=x>>31;
    // return (x&(~negmask))|(~(x+(~(1<<31)))&negmask);//use mask, change a way to calc -x

    // Version 3  8ops
    // int negmask=x>>31;
    // return x+(negmask&((1<<31)+(~(x<<1))+1));//reduce a usage of mask. when negative return x+((1<<31)-2*x) equal to -x

    // Version 4  5ops
    // find by vm(not stack machine)
    // cosr 1.5min on hpc in pku with 36t
    // ((1<<v1)^1) = (x<0)?0xfffffffe:0x00000000
    // (x^v1) = (x<0)?~x:x
    int v1=(x>>31);
    return (x^v1)+((1<<v1)^1);
}
/*
 * satAdd - adds two numbers but when positive overflow occurs, returns
 *          maximum possible value, and when negative overflow occurs,
 *          it returns minimum positive value.
 *   Examples: satAdd(0x40000000,0x40000000) = 0x7fffffff
 *             satAdd(0x80000000,0xffffffff) = 0x80000000
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 30
 *   Rating: 4
 */
int satAdd(int x, int y) {
    // Version 1  13ops
    // int ret=x+y;
    // int mask=((ret^x)&(ret^y))>>31;//check when overflow, 0xffffffff
    // return ret+(mask&((1<<31)+(~ret)+((x>>31)&1)));//when overflow, ((x>>31)&1) means positive/negative
    // so we need 0x7fffffff+(is negative),then  return ret+((1<<<31)-1+((x>>31)&1)-ret)

    // Version 2  8ops
    // inspired by other task's solution by computer
    int ret=x+y;
    int of=((ret^x)&(ret^y))>>31;
    // when overflow ret>>of==ret>>31==(ret<0?-1:0) else ret>>of==ret
    // of<<31==0x80000000 when overflow, else 0
    return (ret>>of)+(of<<31);
}
/*
 * trueFiveEighths - multiplies by 5/8 rounding toward 0,
 *  avoiding errors due to overflow
 *  Examples: trueFiveEighths(11) = 6
 *            trueFiveEighths(-9) = -5
 *            trueFiveEighths(0x30000000) = 0x1E000000 (no overflow)
 *  Legal ops: ! ~ & ^ | + << >>
 *  Max ops: 25
 *  Rating: 4
 */
int trueFiveEighths(int x)
{
    // Version 1  13ops
    // int a=x>>1;
    // int b=x>>3;//x*5/8=x/2+x/8 if no floor
    // int c=x&(x>>2)&1;//floor first is wrong when x%8==5 or 7,then we need to add one
    // int lb=(x&7);
    // int d=(x>>31)&!!lb;//negative number will round to 0, but when x%8=0
    // return a+b+c+d;//add all of them

    // Version 2  11ops
    int a=x>>3;
    int b=a+(a<<2);//calc (x/8)*5 first
    int c=(x&7);
    int d=(c+(c<<2)+((x>>31)&7))>>3;//then (x%8)*5/8, when negative return (x%8+7)*5/8
    return b+d;
}
/* 
 * float_twice - Return bit-level equivalent of expression 2*f for
 *   floating point argument f.
 *   Both the argument and result are passed as unsigned int's, but
 *   they are to be interpreted as the bit-level representation of
 *   single-precision floating point values.
 *   When argument is NaN, return argument
 *   Legal ops: Any integer/unsigned operations incl. ||, &&. also if, while
 *   Max ops: 30
 *   Rating: 4
 */
unsigned float_twice(unsigned uf) {
    // old version
    // unsigned expv=uf&0x7f800000;//exp v
    // unsigned mv=uf&0x7fffff;//significand v
    // unsigned rtv=uf+mv;//if subnormal, add significand directly to double it
    // switch (expv)
    // {
    //     case 0x7f800000: return uf;//is nan or inf
    //     case 0: return rtv;//subnormal
    //     case 0x7f000000: return (uf&0x80000000)+0x7f800000;//normalized but then get inf
    //     default: return uf+0x800000;//normalized and get normalized number
    // }

    // normal version
    // unsigned expv=uf&0xff800000;//exp v&sign v
    // //unsigned mv=uf&0x7fffff;//significand v
    // unsigned rtv=uf+uf;//if subnormal, add significand directly to double it. high bits is full 0 but sign bit.
    // unsigned jiaa=uf;
    // unsigned jiab=0x800000;
    // switch (expv)
    // {
    //     case 0x7f800000://is nan or inf
    //     case 0xff800000: return uf;//is nan or inf
    //     case 0: return rtv;//subnormal sign bit=0
    //     case 0x80000000: jiaa=rtv;jiab=0x80000000;break;//subnotmal sign bit=1, return rtv+0x80000000
    //     case 0x7f000000: return 0x7f800000;
    //     case 0xff000000: return 0xff800000;//normalized but then get inf
    //     default: break;//normalized and get normalized number, return uf+0x800000'
    // }
    // return jiaa+jiab;//add together

    // unsigned expv=uf&0xff800000;//exp v&sign v
    // //unsigned mv=uf&0x7fffff;//significand v
    // unsigned jiaa=uf;
    // unsigned jiab=0x800000;
    // unsigned jiac=0;
    // int nowl=1;
    // int alu0=uf;
    // int alu1=0x7f800000;
    // int alu2=0;
    // int reg0=0;
    // switch (expv)
    // {
    //     case 0x7f800000://is nan or inf
    //     case 0xff800000: return uf;//is nan or inf
    //     case 0: jiaa=uf;jiab=uf;break;//subnormal sign bit=0
    //     case 0x80000000: jiaa=uf;jiab=uf;jiac=0x80000000;break;//subnotmal sign bit=1, return rtv+0x80000000
    //     case 0x7f000000: return 0x7f800000;
    //     case 0xff000000: return 0xff800000;//normalized but then get inf
    //     default: break;//normalized and get normalized number, return uf+0x800000'
    // }
    // nowl=1;
    // alu0=jiaa;
    // alu1=jiab;
    // while(nowl)
    // {
    //     alu2=alu0+alu1;
    //     switch (nowl)
    //     {
    //         case 1:
    //         alu0=alu2;
    //         alu1=jiac;
    //         nowl=2;
    //         break;
    //         case 2:
    //         reg0=alu2;
    //         nowl=0;
    //         break;
    //     }
    // }
    // return reg0;
    int alu0=0,alu1=0,alu2=0;
    int reg0=0,reg1=0,reg2=0,reg7=0;
    int bw0=0,bw1=0,bw2=0,bw3=0,bw4=0,bw5=0,bw6=0,bw7=0,bw8=0,bw9=0,bw10=0,bw11=0,bw12=0,bw13=0,bw14=0,bw15=0,bw16=0,bw17=0,bw18=0,bw19=0,bw20=0,bw21=0,bw22=0,bw23=0,bw24=0,bw25=0,bw26=0,bw27=0,bw28=0,bw29=0,bw30=0,bw31=0;
    int cw23=0,cw24=0,cw25=0,cw26=0,cw27=0,cw28=0,cw29=0,cw30=0,cw31=0;
    int nowl=1;
    int expv=0;
    while(nowl)
    {
        switch(nowl)
        {
            case 1: alu0=uf;alu1=0xff800000;break;
            case 2: alu1=0x1;break;
            case 3: alu1=0x2;break;
            case 4: alu1=0x4;break;
            case 5: alu1=0x8;break;
            case 6: alu1=0x10;break;
            case 7: alu1=0x20;break;
            case 8: alu1=0x40;break;
            case 9: alu1=0x80;break;
            case 10: alu1=0x100;break;
            case 11: alu1=0x200;break;
            case 12: alu1=0x400;break;
            case 13: alu1=0x800;break;
            case 14: alu1=0x1000;break;
            case 15: alu1=0x2000;break;
            case 16: alu1=0x4000;break;
            case 17: alu1=0x8000;break;
            case 18: alu1=0x10000;break;
            case 19: alu1=0x20000;break;
            case 20: alu1=0x40000;break;
            case 21: alu1=0x80000;break;
            case 22: alu1=0x100000;break;
            case 23: alu1=0x200000;break;
            case 24: alu1=0x400000;break;
            case 25: alu1=0x800000;break;
            case 26: alu1=0x1000000;break;
            case 27: alu1=0x2000000;break;
            case 28: alu1=0x4000000;break;
            case 29: alu1=0x8000000;break;
            case 30: alu1=0x10000000;break;
            case 31: alu1=0x20000000;break;
            case 32: alu1=0x40000000;break;
            case 33: alu1=0x80000000;break;
            case 34: alu0=alu2;if(bw0){alu1=0xffffffff;}else{alu1=0xfffffffe;} break;
            case 35: alu0=alu2;if(bw1){alu1=0xffffffff;}else{alu1=0xfffffffd;} break;
            case 36: alu0=alu2;if(bw2){alu1=0xffffffff;}else{alu1=0xfffffffb;} break;
            case 37: alu0=alu2;if(bw3){alu1=0xffffffff;}else{alu1=0xfffffff7;} break;
            case 38: alu0=alu2;if(bw4){alu1=0xffffffff;}else{alu1=0xffffffef;} break;
            case 39: alu0=alu2;if(bw5){alu1=0xffffffff;}else{alu1=0xffffffdf;} break;
            case 40: alu0=alu2;if(bw6){alu1=0xffffffff;}else{alu1=0xffffffbf;} break;
            case 41: alu0=alu2;if(bw7){alu1=0xffffffff;}else{alu1=0xffffff7f;} break;
            case 42: alu0=alu2;if(bw8){alu1=0xffffffff;}else{alu1=0xfffffeff;} break;
            case 43: alu0=alu2;if(bw9){alu1=0xffffffff;}else{alu1=0xfffffdff;} break;
            case 44: alu0=alu2;if(bw10){alu1=0xffffffff;}else{alu1=0xfffffbff;} break;
            case 45: alu0=alu2;if(bw11){alu1=0xffffffff;}else{alu1=0xfffff7ff;} break;
            case 46: alu0=alu2;if(bw12){alu1=0xffffffff;}else{alu1=0xffffefff;} break;
            case 47: alu0=alu2;if(bw13){alu1=0xffffffff;}else{alu1=0xffffdfff;} break;
            case 48: alu0=alu2;if(bw14){alu1=0xffffffff;}else{alu1=0xffffbfff;} break;
            case 49: alu0=alu2;if(bw15){alu1=0xffffffff;}else{alu1=0xffff7fff;} break;
            case 50: alu0=alu2;if(bw16){alu1=0xffffffff;}else{alu1=0xfffeffff;} break;
            case 51: alu0=alu2;if(bw17){alu1=0xffffffff;}else{alu1=0xfffdffff;} break;
            case 52: alu0=alu2;if(bw18){alu1=0xffffffff;}else{alu1=0xfffbffff;} break;
            case 53: alu0=alu2;if(bw19){alu1=0xffffffff;}else{alu1=0xfff7ffff;} break;
            case 54: alu0=alu2;if(bw20){alu1=0xffffffff;}else{alu1=0xffefffff;} break;
            case 55: alu0=alu2;if(bw21){alu1=0xffffffff;}else{alu1=0xffdfffff;} break;
            case 56: alu0=alu2;if(bw22){alu1=0xffffffff;}else{alu1=0xffbfffff;} break;
            case 57: if(bw23){if(cw23){if(reg2){reg1=1;reg2=1;}else{reg1=0;reg2=1;}}else{if(reg2){reg1=0;reg2=1;}else{reg1=1;reg2=0;}}}else{if(cw23){if(reg2){reg1=0;reg2=1;}else{reg1=1;reg2=0;}}else{if(reg2){reg1=1;reg2=0;}else{reg1=0;reg2=0;}}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xff7fffff;} break;
            case 58: if(bw24){if(cw24){if(reg2){reg1=1;reg2=1;}else{reg1=0;reg2=1;}}else{if(reg2){reg1=0;reg2=1;}else{reg1=1;reg2=0;}}}else{if(cw24){if(reg2){reg1=0;reg2=1;}else{reg1=1;reg2=0;}}else{if(reg2){reg1=1;reg2=0;}else{reg1=0;reg2=0;}}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xfeffffff;} break;
            case 59: if(bw25){if(cw25){if(reg2){reg1=1;reg2=1;}else{reg1=0;reg2=1;}}else{if(reg2){reg1=0;reg2=1;}else{reg1=1;reg2=0;}}}else{if(cw25){if(reg2){reg1=0;reg2=1;}else{reg1=1;reg2=0;}}else{if(reg2){reg1=1;reg2=0;}else{reg1=0;reg2=0;}}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xfdffffff;} break;
            case 60: if(bw26){if(cw26){if(reg2){reg1=1;reg2=1;}else{reg1=0;reg2=1;}}else{if(reg2){reg1=0;reg2=1;}else{reg1=1;reg2=0;}}}else{if(cw26){if(reg2){reg1=0;reg2=1;}else{reg1=1;reg2=0;}}else{if(reg2){reg1=1;reg2=0;}else{reg1=0;reg2=0;}}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xfbffffff;} break;
            case 61: if(bw27){if(cw27){if(reg2){reg1=1;reg2=1;}else{reg1=0;reg2=1;}}else{if(reg2){reg1=0;reg2=1;}else{reg1=1;reg2=0;}}}else{if(cw27){if(reg2){reg1=0;reg2=1;}else{reg1=1;reg2=0;}}else{if(reg2){reg1=1;reg2=0;}else{reg1=0;reg2=0;}}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xf7ffffff;} break;
            case 62: if(bw28){if(cw28){if(reg2){reg1=1;reg2=1;}else{reg1=0;reg2=1;}}else{if(reg2){reg1=0;reg2=1;}else{reg1=1;reg2=0;}}}else{if(cw28){if(reg2){reg1=0;reg2=1;}else{reg1=1;reg2=0;}}else{if(reg2){reg1=1;reg2=0;}else{reg1=0;reg2=0;}}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xefffffff;} break;
            case 63: if(bw29){if(cw29){if(reg2){reg1=1;reg2=1;}else{reg1=0;reg2=1;}}else{if(reg2){reg1=0;reg2=1;}else{reg1=1;reg2=0;}}}else{if(cw29){if(reg2){reg1=0;reg2=1;}else{reg1=1;reg2=0;}}else{if(reg2){reg1=1;reg2=0;}else{reg1=0;reg2=0;}}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xdfffffff;} break;
            case 64: if(bw30){if(cw30){if(reg2){reg1=1;reg2=1;}else{reg1=0;reg2=1;}}else{if(reg2){reg1=0;reg2=1;}else{reg1=1;reg2=0;}}}else{if(cw30){if(reg2){reg1=0;reg2=1;}else{reg1=1;reg2=0;}}else{if(reg2){reg1=1;reg2=0;}else{reg1=0;reg2=0;}}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xbfffffff;} break;
            case 65: if(bw31){if(cw31){if(reg2){reg1=1;reg2=1;}else{reg1=0;reg2=1;}}else{if(reg2){reg1=0;reg2=1;}else{reg1=1;reg2=0;}}}else{if(cw31){if(reg2){reg1=0;reg2=1;}else{reg1=1;reg2=0;}}else{if(reg2){reg1=1;reg2=0;}else{reg1=0;reg2=0;}}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0x7fffffff;} break;
        }
        alu2=alu0&alu1;
        switch(nowl)
        {
            case 1: expv=alu2;
            switch(expv)
            {
                case 0x7f800000: case 0xff800000: return uf;
                case 0x7f000000: return 0x7f800000;
                case 0xff000000: return 0xff800000;
                case 0: reg0=1;break;
                case 0x80000000: reg0=1;cw31=1;break;
                default: cw23=1;break;
            }nowl=2;break;
            case 2: bw0=alu2;nowl=3;break;
            case 3: bw1=alu2;nowl=4;break;
            case 4: bw2=alu2;nowl=5;break;
            case 5: bw3=alu2;nowl=6;break;
            case 6: bw4=alu2;nowl=7;break;
            case 7: bw5=alu2;nowl=8;break;
            case 8: bw6=alu2;nowl=9;break;
            case 9: bw7=alu2;nowl=10;break;
            case 10: bw8=alu2;nowl=11;break;
            case 11: bw9=alu2;nowl=12;break;
            case 12: bw10=alu2;nowl=13;break;
            case 13: bw11=alu2;nowl=14;break;
            case 14: bw12=alu2;nowl=15;break;
            case 15: bw13=alu2;nowl=16;break;
            case 16: bw14=alu2;nowl=17;break;
            case 17: bw15=alu2;nowl=18;break;
            case 18: bw16=alu2;nowl=19;break;
            case 19: bw17=alu2;nowl=20;break;
            case 20: bw18=alu2;nowl=21;break;
            case 21: bw19=alu2;nowl=22;break;
            case 22: bw20=alu2;nowl=23;break;
            case 23: bw21=alu2;nowl=24;break;
            case 24: bw22=alu2;nowl=25;break;
            case 25: bw23=alu2;nowl=26;break;
            case 26: bw24=alu2;nowl=27;break;
            case 27: bw25=alu2;nowl=28;break;
            case 28: bw26=alu2;nowl=29;break;
            case 29: bw27=alu2;nowl=30;break;
            case 30: bw28=alu2;nowl=31;break;
            case 31: bw29=alu2;nowl=32;break;
            case 32: bw30=alu2;nowl=33;break;
            case 33: bw31=alu2;nowl=34;if(reg0){bw31=bw30;bw30=bw29;bw29=bw28;bw28=bw27;bw27=bw26;bw26=bw25;bw25=bw24;bw24=bw23;bw23=bw22;bw22=bw21;bw21=bw20;bw20=bw19;bw19=bw18;bw18=bw17;bw17=bw16;bw16=bw15;bw15=bw14;bw14=bw13;bw13=bw12;bw12=bw11;bw11=bw10;bw10=bw9;bw9=bw8;bw8=bw7;bw7=bw6;bw6=bw5;bw5=bw4;bw4=bw3;bw3=bw2;bw2=bw1;bw1=bw0;bw0=0;}alu2=0xffffffff;break;
            case 34: nowl=35;break;
            case 35: nowl=36;break;
            case 36: nowl=37;break;
            case 37: nowl=38;break;
            case 38: nowl=39;break;
            case 39: nowl=40;break;
            case 40: nowl=41;break;
            case 41: nowl=42;break;
            case 42: nowl=43;break;
            case 43: nowl=44;break;
            case 44: nowl=45;break;
            case 45: nowl=46;break;
            case 46: nowl=47;break;
            case 47: nowl=48;break;
            case 48: nowl=49;break;
            case 49: nowl=50;break;
            case 50: nowl=51;break;
            case 51: nowl=52;break;
            case 52: nowl=53;break;
            case 53: nowl=54;break;
            case 54: nowl=55;break;
            case 55: nowl=56;break;
            case 56: nowl=57;break;
            case 57: nowl=58;break;
            case 58: nowl=59;break;
            case 59: nowl=60;break;
            case 60: nowl=61;break;
            case 61: nowl=62;break;
            case 62: nowl=63;break;
            case 63: nowl=64;break;
            case 64: nowl=65;break;
            case 65: nowl=0;reg7=alu2;break;
        }
    }
    return reg7;
}
/* 
 * float_half - Return bit-level equivalent of expression 0.5*f for
 *   floating point argument f.
 *   Both the argument and result are passed as unsigned int's, but
 *   they are to be interpreted as the bit-level representation of
 *   single-precision floating point values.
 *   When argument is NaN, return argument
 *   Legal ops: Any integer/unsigned operations incl. ||, &&. also if, while
 *   Max ops: 30
 *   Rating: 4
 */
unsigned float_half(unsigned uf) {
    // normal version
    // unsigned expv=uf&0x7f800000;
    // unsigned mv=uf&0xffffff;//use 1 more digit
    // unsigned hfv=mv>>1;//mv/2 floor
    // unsigned rtv=uf-hfv;//if subnormal, sub significand directly to half it
    // int jiana=rtv;
    // int jianb=1;
    // switch (expv)
    // {
    //     case 0x7f800000: return uf;//nan or inf
    //     case 0x800000://when exp==1 we can process it as subnormal
    //     case 0://subnormal. round to even, need to sub 1 more when 2-bit is 01.
    //         switch (mv&3)
    //         {
    //             case 0:
    //             case 2:
    //             case 3: return rtv;
    //             case 1: break;//return rtv-1
    //         }
    //         break;
    //     default: jiana=uf;jianb=0x800000;break;//normalized, return uf-0x800000
    // }
    //return jiana-jianb;

    // unsigned expv=0;
    // unsigned mv=0;//use 1 more digit
    // unsigned lbv=0;
    // unsigned hfv=0;//mv/2 floor
    // int nowl=1;
    // int alu0=uf;
    // int alu1=0x7f800000;
    // int alu2=0;
    // int reg0=0;
    // int jiana=0;
    // int jianb=0;
    // int jianc=0;
    // while(nowl)
    // {
    //     alu2=alu0&alu1;
    //     switch(nowl)
    //     {
    //         case 1:
    //         expv=alu2;
    //         nowl=2;
    //         alu1=0xffffff;
    //         break;
    //         case 2:
    //         mv=alu2;
    //         nowl=3;
    //         alu0=mv;
    //         alu1=3;
    //         break;
    //         case 3:
    //         lbv=alu2;
    //         nowl=0;
    //         break;
    //     }
    // }
    // hfv=mv>>1;
    // switch (expv)
    // {
    //     case 0x7f800000: return uf;//nan or inf
    //     case 0x800000://when exp==1 we can process it as subnormal
    //     case 0://subnormal. round to even, need to sub 1 more when 2-bit is 01.
    //         switch (lbv)
    //         {
    //             case 0:
    //             case 2:
    //             case 3: jiana=uf;jianb=hfv;jianc=0;break;
    //             case 1: jiana=uf;jianb=hfv;jianc=1;break;
    //         }
    //         break;
    //     default: jiana=uf;jianb=0x800000;jianc=0;break;//normalized, return uf-0x800000
    // }
    // nowl=1;
    // alu0=jiana;
    // alu1=jianb;
    // while(nowl)
    // {
    //     alu2=alu0-alu1;
    //     switch (nowl)
    //     {
    //         case 1:
    //         alu0=alu2;
    //         alu1=jianc;
    //         nowl=2;
    //         break;
    //         case 2:
    //         reg0=alu2;
    //         nowl=0;
    //         break;
    //     }
    // }
    // return reg0;

    int alu0=0,alu1=0,alu2=0;
    int reg0=1,reg1=0,reg2=0,reg7=0;
    int bw0=0,bw1=0,bw2=0,bw3=0,bw4=0,bw5=0,bw6=0,bw7=0,bw8=0,bw9=0,bw10=0,bw11=0,bw12=0,bw13=0,bw14=0,bw15=0,bw16=0,bw17=0,bw18=0,bw19=0,bw20=0,bw21=0,bw22=0,bw23=0,bw24=0,bw25=0,bw26=0,bw27=0,bw28=0,bw29=0,bw30=0,bw31=0;
    int cw0=0,cw23=0,cw24=0,cw25=0,cw26=0,cw27=0,cw28=0,cw29=0,cw30=0,cw31=0;
    int nowl=1;
    int expv=0;
    while(nowl)
    {
        switch(nowl)
        {
            case 1: alu0=uf;alu1=0xff800003;break;
            case 2: alu1=0x1;break;
            case 3: alu1=0x2;break;
            case 4: alu1=0x4;break;
            case 5: alu1=0x8;break;
            case 6: alu1=0x10;break;
            case 7: alu1=0x20;break;
            case 8: alu1=0x40;break;
            case 9: alu1=0x80;break;
            case 10: alu1=0x100;break;
            case 11: alu1=0x200;break;
            case 12: alu1=0x400;break;
            case 13: alu1=0x800;break;
            case 14: alu1=0x1000;break;
            case 15: alu1=0x2000;break;
            case 16: alu1=0x4000;break;
            case 17: alu1=0x8000;break;
            case 18: alu1=0x10000;break;
            case 19: alu1=0x20000;break;
            case 20: alu1=0x40000;break;
            case 21: alu1=0x80000;break;
            case 22: alu1=0x100000;break;
            case 23: alu1=0x200000;break;
            case 24: alu1=0x400000;break;
            case 25: alu1=0x800000;break;
            case 26: alu1=0x1000000;break;
            case 27: alu1=0x2000000;break;
            case 28: alu1=0x4000000;break;
            case 29: alu1=0x8000000;break;
            case 30: alu1=0x10000000;break;
            case 31: alu1=0x20000000;break;
            case 32: alu1=0x40000000;break;
            case 33: alu1=0x80000000;break;
            case 34: reg1=0;if(bw0){if(cw0){if(reg2){reg1=1;}else{reg2=1;}}else{if(reg2){}else{reg1=1;}}}else{if(cw0){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xfffffffe;} break;
            case 35: reg1=0;if(bw1){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xfffffffd;} break;
            case 36: reg1=0;if(bw2){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xfffffffb;} break;
            case 37: reg1=0;if(bw3){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xfffffff7;} break;
            case 38: reg1=0;if(bw4){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xffffffef;} break;
            case 39: reg1=0;if(bw5){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xffffffdf;} break;
            case 40: reg1=0;if(bw6){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xffffffbf;} break;
            case 41: reg1=0;if(bw7){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xffffff7f;} break;
            case 42: reg1=0;if(bw8){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xfffffeff;} break;
            case 43: reg1=0;if(bw9){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xfffffdff;} break;
            case 44: reg1=0;if(bw10){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xfffffbff;} break;
            case 45: reg1=0;if(bw11){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xfffff7ff;} break;
            case 46: reg1=0;if(bw12){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xffffefff;} break;
            case 47: reg1=0;if(bw13){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xffffdfff;} break;
            case 48: reg1=0;if(bw14){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xffffbfff;} break;
            case 49: reg1=0;if(bw15){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xffff7fff;} break;
            case 50: reg1=0;if(bw16){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xfffeffff;} break;
            case 51: reg1=0;if(bw17){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xfffdffff;} break;
            case 52: reg1=0;if(bw18){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xfffbffff;} break;
            case 53: reg1=0;if(bw19){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xfff7ffff;} break;
            case 54: reg1=0;if(bw20){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xffefffff;} break;
            case 55: reg1=0;if(bw21){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xffdfffff;} break;
            case 56: reg1=0;if(bw22){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xffbfffff;} break;
            case 57: reg1=0;if(bw23){if(cw23){if(reg2){reg1=1;}else{reg2=1;}}else{if(reg2){}else{reg1=1;}}}else{if(cw23){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xff7fffff;} break;
            case 58: reg1=0;if(bw24){if(cw24){if(reg2){reg1=1;}else{reg2=1;}}else{if(reg2){}else{reg1=1;}}}else{if(cw24){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xfeffffff;} break;
            case 59: reg1=0;if(bw25){if(cw25){if(reg2){reg1=1;}else{reg2=1;}}else{if(reg2){}else{reg1=1;}}}else{if(cw25){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xfdffffff;} break;
            case 60: reg1=0;if(bw26){if(cw26){if(reg2){reg1=1;}else{reg2=1;}}else{if(reg2){}else{reg1=1;}}}else{if(cw26){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xfbffffff;} break;
            case 61: reg1=0;if(bw27){if(cw27){if(reg2){reg1=1;}else{reg2=1;}}else{if(reg2){}else{reg1=1;}}}else{if(cw27){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xf7ffffff;} break;
            case 62: reg1=0;if(bw28){if(cw28){if(reg2){reg1=1;}else{reg2=1;}}else{if(reg2){}else{reg1=1;}}}else{if(cw28){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xefffffff;} break;
            case 63: reg1=0;if(bw29){if(cw29){if(reg2){reg1=1;}else{reg2=1;}}else{if(reg2){}else{reg1=1;}}}else{if(cw29){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xdfffffff;} break;
            case 64: reg1=0;if(bw30){if(cw30){if(reg2){reg1=1;}else{reg2=1;}}else{if(reg2){}else{reg1=1;}}}else{if(cw30){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0xbfffffff;} break;
            case 65: reg1=0;if(bw31){if(cw31){if(reg2){reg1=1;}else{reg2=1;}}else{if(reg2){}else{reg1=1;}}}else{if(cw31){if(reg2){}else{reg1=1;}}else{if(reg2){reg1=1;reg2=0;}else{}}}alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0x7fffffff;} break;
        }
        alu2=alu0&alu1;
        switch(nowl)
        {
            case 1: expv=alu2;
            switch(expv)
            {
                case 0x7f800000: case 0x7f800001: case 0x7f800002: case 0x7f800003: case 0xff800000: case 0xff800001: case 0xff800002: case 0xff800003: return uf;
                case 0: case 1: case 2: case 0x800000: case 0x800001: case 0x800002: break;
                case 3: case 0x800003: cw0=1;break;
                case 0x80000000: case 0x80000001: case 0x80000002: case 0x80800000: case 0x80800001: case 0x80800002: cw30=1;break;
                case 0x80000003: case 0x80800003: cw30=1;cw0=1;break;
                default: reg0=0;cw23=1;cw24=1;cw25=1;cw26=1;cw27=1;cw28=1;cw29=1;cw30=1;cw31=1;break;
            }nowl=2;break;
            case 2: bw0=alu2;nowl=3;break;
            case 3: bw1=alu2;nowl=4;break;
            case 4: bw2=alu2;nowl=5;break;
            case 5: bw3=alu2;nowl=6;break;
            case 6: bw4=alu2;nowl=7;break;
            case 7: bw5=alu2;nowl=8;break;
            case 8: bw6=alu2;nowl=9;break;
            case 9: bw7=alu2;nowl=10;break;
            case 10: bw8=alu2;nowl=11;break;
            case 11: bw9=alu2;nowl=12;break;
            case 12: bw10=alu2;nowl=13;break;
            case 13: bw11=alu2;nowl=14;break;
            case 14: bw12=alu2;nowl=15;break;
            case 15: bw13=alu2;nowl=16;break;
            case 16: bw14=alu2;nowl=17;break;
            case 17: bw15=alu2;nowl=18;break;
            case 18: bw16=alu2;nowl=19;break;
            case 19: bw17=alu2;nowl=20;break;
            case 20: bw18=alu2;nowl=21;break;
            case 21: bw19=alu2;nowl=22;break;
            case 22: bw20=alu2;nowl=23;break;
            case 23: bw21=alu2;nowl=24;break;
            case 24: bw22=alu2;nowl=25;break;
            case 25: bw23=alu2;nowl=26;break;
            case 26: bw24=alu2;nowl=27;break;
            case 27: bw25=alu2;nowl=28;break;
            case 28: bw26=alu2;nowl=29;break;
            case 29: bw27=alu2;nowl=30;break;
            case 30: bw28=alu2;nowl=31;break;
            case 31: bw29=alu2;nowl=32;break;
            case 32: bw30=alu2;nowl=33;break;
            case 33: bw31=alu2;nowl=34;if(reg0){bw0=bw1;bw1=bw2;bw2=bw3;bw3=bw4;bw4=bw5;bw5=bw6;bw6=bw7;bw7=bw8;bw8=bw9;bw9=bw10;bw10=bw11;bw11=bw12;bw12=bw13;bw13=bw14;bw14=bw15;bw15=bw16;bw16=bw17;bw17=bw18;bw18=bw19;bw19=bw20;bw20=bw21;bw21=bw22;bw22=bw23;bw23=bw24;bw24=bw25;bw25=bw26;bw26=bw27;bw27=bw28;bw28=bw29;bw29=bw30;bw30=bw31;bw31=0;}alu2=0xffffffff;break;
            case 34: nowl=35;break;
            case 35: nowl=36;break;
            case 36: nowl=37;break;
            case 37: nowl=38;break;
            case 38: nowl=39;break;
            case 39: nowl=40;break;
            case 40: nowl=41;break;
            case 41: nowl=42;break;
            case 42: nowl=43;break;
            case 43: nowl=44;break;
            case 44: nowl=45;break;
            case 45: nowl=46;break;
            case 46: nowl=47;break;
            case 47: nowl=48;break;
            case 48: nowl=49;break;
            case 49: nowl=50;break;
            case 50: nowl=51;break;
            case 51: nowl=52;break;
            case 52: nowl=53;break;
            case 53: nowl=54;break;
            case 54: nowl=55;break;
            case 55: nowl=56;break;
            case 56: nowl=57;break;
            case 57: nowl=58;break;
            case 58: nowl=59;break;
            case 59: nowl=60;break;
            case 60: nowl=61;break;
            case 61: nowl=62;break;
            case 62: nowl=63;break;
            case 63: nowl=64;break;
            case 64: nowl=65;break;
            case 65: nowl=0;reg7=alu2;break;
        }
    }
    return reg7;

}
/* 
 * float_f2i - Return bit-level equivalent of expression (int) f
 *   for floating point argument f.
 *   Argument is passed as unsigned int, but
 *   it is to be interpreted as the bit-level representation of a
 *   single-precision floating point value.
 *   Anything out of range (including NaN and infinity) should return
 *   0x80000000u.
 *   Legal ops: Any integer/unsigned operations incl. ||, &&. also if, while
 *   Max ops: 30
 *   Rating: 4
 */
int float_f2i(unsigned uf) {
    //old version
    // int sf=uf;
    // unsigned expv=(uf>>23)&255;
    // unsigned mv=uf&0x7fffff;
    // unsigned sv=sf<0;//check sign
    // unsigned basev=(0x800000+mv);//real significand
    // int ssv=expv>=150?(basev<<(expv-150)):(basev>>(150-expv));//use the exactly expv to get the abs value
    // if(expv<127)    return 0;//too small
    // if(expv>=158)   return 0x80000000u;//too large
    // return sv?-ssv:ssv;//use sign

//     unsigned expv=0;
//     unsigned mv=uf;
//     unsigned sv=0;
//     int basev=0;
//     int movlv=0;
//     int movrv=0;
//     int ssv=0;
//     int nowl=1;
//     int nexl=0;
//     int alu0=uf;
//     int alu1=0xff800000;
//     int alu2=0;
//     int reg0=0;
//     int reg1=0;
//     int reg2=0;
//     int reg3=0;
//     while(nowl)
//     {
//         alu2=alu0&alu1;
//         switch(nowl)
//         {
//             case 1:
//             expv=alu2;
//             nowl=2;
//             alu1=0x7fffff;
//             break;
//             case 2:
//             mv=alu2;
//             nowl=0;
//             break;
//         }
//     }
// /*generated by python 
// txt=""
// for expv in range(0,127):
//  txt=txt+"case %d:\n"%expv
// txt=txt+"return 0;\n"
// for expv in range(158,256):
//  txt=txt+"case %d:\n"%expv
// txt=txt+"return 0x80000000u;\n"
// print(txt)
// **/
//     switch (expv)
//     {
//         case 0x0:
//         case 0x80000000:
//         case 0x800000:
//         case 0x80800000:
//         case 0x1000000:
//         case 0x81000000:
//         case 0x1800000:
//         case 0x81800000:
//         case 0x2000000:
//         case 0x82000000:
//         case 0x2800000:
//         case 0x82800000:
//         case 0x3000000:
//         case 0x83000000:
//         case 0x3800000:
//         case 0x83800000:
//         case 0x4000000:
//         case 0x84000000:
//         case 0x4800000:
//         case 0x84800000:
//         case 0x5000000:
//         case 0x85000000:
//         case 0x5800000:
//         case 0x85800000:
//         case 0x6000000:
//         case 0x86000000:
//         case 0x6800000:
//         case 0x86800000:
//         case 0x7000000:
//         case 0x87000000:
//         case 0x7800000:
//         case 0x87800000:
//         case 0x8000000:
//         case 0x88000000:
//         case 0x8800000:
//         case 0x88800000:
//         case 0x9000000:
//         case 0x89000000:
//         case 0x9800000:
//         case 0x89800000:
//         case 0xa000000:
//         case 0x8a000000:
//         case 0xa800000:
//         case 0x8a800000:
//         case 0xb000000:
//         case 0x8b000000:
//         case 0xb800000:
//         case 0x8b800000:
//         case 0xc000000:
//         case 0x8c000000:
//         case 0xc800000:
//         case 0x8c800000:
//         case 0xd000000:
//         case 0x8d000000:
//         case 0xd800000:
//         case 0x8d800000:
//         case 0xe000000:
//         case 0x8e000000:
//         case 0xe800000:
//         case 0x8e800000:
//         case 0xf000000:
//         case 0x8f000000:
//         case 0xf800000:
//         case 0x8f800000:
//         case 0x10000000:
//         case 0x90000000:
//         case 0x10800000:
//         case 0x90800000:
//         case 0x11000000:
//         case 0x91000000:
//         case 0x11800000:
//         case 0x91800000:
//         case 0x12000000:
//         case 0x92000000:
//         case 0x12800000:
//         case 0x92800000:
//         case 0x13000000:
//         case 0x93000000:
//         case 0x13800000:
//         case 0x93800000:
//         case 0x14000000:
//         case 0x94000000:
//         case 0x14800000:
//         case 0x94800000:
//         case 0x15000000:
//         case 0x95000000:
//         case 0x15800000:
//         case 0x95800000:
//         case 0x16000000:
//         case 0x96000000:
//         case 0x16800000:
//         case 0x96800000:
//         case 0x17000000:
//         case 0x97000000:
//         case 0x17800000:
//         case 0x97800000:
//         case 0x18000000:
//         case 0x98000000:
//         case 0x18800000:
//         case 0x98800000:
//         case 0x19000000:
//         case 0x99000000:
//         case 0x19800000:
//         case 0x99800000:
//         case 0x1a000000:
//         case 0x9a000000:
//         case 0x1a800000:
//         case 0x9a800000:
//         case 0x1b000000:
//         case 0x9b000000:
//         case 0x1b800000:
//         case 0x9b800000:
//         case 0x1c000000:
//         case 0x9c000000:
//         case 0x1c800000:
//         case 0x9c800000:
//         case 0x1d000000:
//         case 0x9d000000:
//         case 0x1d800000:
//         case 0x9d800000:
//         case 0x1e000000:
//         case 0x9e000000:
//         case 0x1e800000:
//         case 0x9e800000:
//         case 0x1f000000:
//         case 0x9f000000:
//         case 0x1f800000:
//         case 0x9f800000:
//         case 0x20000000:
//         case 0xa0000000:
//         case 0x20800000:
//         case 0xa0800000:
//         case 0x21000000:
//         case 0xa1000000:
//         case 0x21800000:
//         case 0xa1800000:
//         case 0x22000000:
//         case 0xa2000000:
//         case 0x22800000:
//         case 0xa2800000:
//         case 0x23000000:
//         case 0xa3000000:
//         case 0x23800000:
//         case 0xa3800000:
//         case 0x24000000:
//         case 0xa4000000:
//         case 0x24800000:
//         case 0xa4800000:
//         case 0x25000000:
//         case 0xa5000000:
//         case 0x25800000:
//         case 0xa5800000:
//         case 0x26000000:
//         case 0xa6000000:
//         case 0x26800000:
//         case 0xa6800000:
//         case 0x27000000:
//         case 0xa7000000:
//         case 0x27800000:
//         case 0xa7800000:
//         case 0x28000000:
//         case 0xa8000000:
//         case 0x28800000:
//         case 0xa8800000:
//         case 0x29000000:
//         case 0xa9000000:
//         case 0x29800000:
//         case 0xa9800000:
//         case 0x2a000000:
//         case 0xaa000000:
//         case 0x2a800000:
//         case 0xaa800000:
//         case 0x2b000000:
//         case 0xab000000:
//         case 0x2b800000:
//         case 0xab800000:
//         case 0x2c000000:
//         case 0xac000000:
//         case 0x2c800000:
//         case 0xac800000:
//         case 0x2d000000:
//         case 0xad000000:
//         case 0x2d800000:
//         case 0xad800000:
//         case 0x2e000000:
//         case 0xae000000:
//         case 0x2e800000:
//         case 0xae800000:
//         case 0x2f000000:
//         case 0xaf000000:
//         case 0x2f800000:
//         case 0xaf800000:
//         case 0x30000000:
//         case 0xb0000000:
//         case 0x30800000:
//         case 0xb0800000:
//         case 0x31000000:
//         case 0xb1000000:
//         case 0x31800000:
//         case 0xb1800000:
//         case 0x32000000:
//         case 0xb2000000:
//         case 0x32800000:
//         case 0xb2800000:
//         case 0x33000000:
//         case 0xb3000000:
//         case 0x33800000:
//         case 0xb3800000:
//         case 0x34000000:
//         case 0xb4000000:
//         case 0x34800000:
//         case 0xb4800000:
//         case 0x35000000:
//         case 0xb5000000:
//         case 0x35800000:
//         case 0xb5800000:
//         case 0x36000000:
//         case 0xb6000000:
//         case 0x36800000:
//         case 0xb6800000:
//         case 0x37000000:
//         case 0xb7000000:
//         case 0x37800000:
//         case 0xb7800000:
//         case 0x38000000:
//         case 0xb8000000:
//         case 0x38800000:
//         case 0xb8800000:
//         case 0x39000000:
//         case 0xb9000000:
//         case 0x39800000:
//         case 0xb9800000:
//         case 0x3a000000:
//         case 0xba000000:
//         case 0x3a800000:
//         case 0xba800000:
//         case 0x3b000000:
//         case 0xbb000000:
//         case 0x3b800000:
//         case 0xbb800000:
//         case 0x3c000000:
//         case 0xbc000000:
//         case 0x3c800000:
//         case 0xbc800000:
//         case 0x3d000000:
//         case 0xbd000000:
//         case 0x3d800000:
//         case 0xbd800000:
//         case 0x3e000000:
//         case 0xbe000000:
//         case 0x3e800000:
//         case 0xbe800000:
//         case 0x3f000000:
//         case 0xbf000000:
//         return 0;
//         case 0x4f000000:
//         case 0xcf000000:
//         case 0x4f800000:
//         case 0xcf800000:
//         case 0x50000000:
//         case 0xd0000000:
//         case 0x50800000:
//         case 0xd0800000:
//         case 0x51000000:
//         case 0xd1000000:
//         case 0x51800000:
//         case 0xd1800000:
//         case 0x52000000:
//         case 0xd2000000:
//         case 0x52800000:
//         case 0xd2800000:
//         case 0x53000000:
//         case 0xd3000000:
//         case 0x53800000:
//         case 0xd3800000:
//         case 0x54000000:
//         case 0xd4000000:
//         case 0x54800000:
//         case 0xd4800000:
//         case 0x55000000:
//         case 0xd5000000:
//         case 0x55800000:
//         case 0xd5800000:
//         case 0x56000000:
//         case 0xd6000000:
//         case 0x56800000:
//         case 0xd6800000:
//         case 0x57000000:
//         case 0xd7000000:
//         case 0x57800000:
//         case 0xd7800000:
//         case 0x58000000:
//         case 0xd8000000:
//         case 0x58800000:
//         case 0xd8800000:
//         case 0x59000000:
//         case 0xd9000000:
//         case 0x59800000:
//         case 0xd9800000:
//         case 0x5a000000:
//         case 0xda000000:
//         case 0x5a800000:
//         case 0xda800000:
//         case 0x5b000000:
//         case 0xdb000000:
//         case 0x5b800000:
//         case 0xdb800000:
//         case 0x5c000000:
//         case 0xdc000000:
//         case 0x5c800000:
//         case 0xdc800000:
//         case 0x5d000000:
//         case 0xdd000000:
//         case 0x5d800000:
//         case 0xdd800000:
//         case 0x5e000000:
//         case 0xde000000:
//         case 0x5e800000:
//         case 0xde800000:
//         case 0x5f000000:
//         case 0xdf000000:
//         case 0x5f800000:
//         case 0xdf800000:
//         case 0x60000000:
//         case 0xe0000000:
//         case 0x60800000:
//         case 0xe0800000:
//         case 0x61000000:
//         case 0xe1000000:
//         case 0x61800000:
//         case 0xe1800000:
//         case 0x62000000:
//         case 0xe2000000:
//         case 0x62800000:
//         case 0xe2800000:
//         case 0x63000000:
//         case 0xe3000000:
//         case 0x63800000:
//         case 0xe3800000:
//         case 0x64000000:
//         case 0xe4000000:
//         case 0x64800000:
//         case 0xe4800000:
//         case 0x65000000:
//         case 0xe5000000:
//         case 0x65800000:
//         case 0xe5800000:
//         case 0x66000000:
//         case 0xe6000000:
//         case 0x66800000:
//         case 0xe6800000:
//         case 0x67000000:
//         case 0xe7000000:
//         case 0x67800000:
//         case 0xe7800000:
//         case 0x68000000:
//         case 0xe8000000:
//         case 0x68800000:
//         case 0xe8800000:
//         case 0x69000000:
//         case 0xe9000000:
//         case 0x69800000:
//         case 0xe9800000:
//         case 0x6a000000:
//         case 0xea000000:
//         case 0x6a800000:
//         case 0xea800000:
//         case 0x6b000000:
//         case 0xeb000000:
//         case 0x6b800000:
//         case 0xeb800000:
//         case 0x6c000000:
//         case 0xec000000:
//         case 0x6c800000:
//         case 0xec800000:
//         case 0x6d000000:
//         case 0xed000000:
//         case 0x6d800000:
//         case 0xed800000:
//         case 0x6e000000:
//         case 0xee000000:
//         case 0x6e800000:
//         case 0xee800000:
//         case 0x6f000000:
//         case 0xef000000:
//         case 0x6f800000:
//         case 0xef800000:
//         case 0x70000000:
//         case 0xf0000000:
//         case 0x70800000:
//         case 0xf0800000:
//         case 0x71000000:
//         case 0xf1000000:
//         case 0x71800000:
//         case 0xf1800000:
//         case 0x72000000:
//         case 0xf2000000:
//         case 0x72800000:
//         case 0xf2800000:
//         case 0x73000000:
//         case 0xf3000000:
//         case 0x73800000:
//         case 0xf3800000:
//         case 0x74000000:
//         case 0xf4000000:
//         case 0x74800000:
//         case 0xf4800000:
//         case 0x75000000:
//         case 0xf5000000:
//         case 0x75800000:
//         case 0xf5800000:
//         case 0x76000000:
//         case 0xf6000000:
//         case 0x76800000:
//         case 0xf6800000:
//         case 0x77000000:
//         case 0xf7000000:
//         case 0x77800000:
//         case 0xf7800000:
//         case 0x78000000:
//         case 0xf8000000:
//         case 0x78800000:
//         case 0xf8800000:
//         case 0x79000000:
//         case 0xf9000000:
//         case 0x79800000:
//         case 0xf9800000:
//         case 0x7a000000:
//         case 0xfa000000:
//         case 0x7a800000:
//         case 0xfa800000:
//         case 0x7b000000:
//         case 0xfb000000:
//         case 0x7b800000:
//         case 0xfb800000:
//         case 0x7c000000:
//         case 0xfc000000:
//         case 0x7c800000:
//         case 0xfc800000:
//         case 0x7d000000:
//         case 0xfd000000:
//         case 0x7d800000:
//         case 0xfd800000:
//         case 0x7e000000:
//         case 0xfe000000:
//         case 0x7e800000:
//         case 0xfe800000:
//         case 0x7f000000:
//         case 0xff000000:
//         case 0x7f800000:
//         case 0xff800000:
//         return 0x80000000u;
//         case 0x3f800000: movrv=23; break;
//         case 0xbf800000: movrv=23; sv=1; break;
//         case 0x40000000: movrv=22; break;
//         case 0xc0000000: movrv=22; sv=1; break;
//         case 0x40800000: movrv=21; break;
//         case 0xc0800000: movrv=21; sv=1; break;
//         case 0x41000000: movrv=20; break;
//         case 0xc1000000: movrv=20; sv=1; break;
//         case 0x41800000: movrv=19; break;
//         case 0xc1800000: movrv=19; sv=1; break;
//         case 0x42000000: movrv=18; break;
//         case 0xc2000000: movrv=18; sv=1; break;
//         case 0x42800000: movrv=17; break;
//         case 0xc2800000: movrv=17; sv=1; break;
//         case 0x43000000: movrv=16; break;
//         case 0xc3000000: movrv=16; sv=1; break;
//         case 0x43800000: movrv=15; break;
//         case 0xc3800000: movrv=15; sv=1; break;
//         case 0x44000000: movrv=14; break;
//         case 0xc4000000: movrv=14; sv=1; break;
//         case 0x44800000: movrv=13; break;
//         case 0xc4800000: movrv=13; sv=1; break;
//         case 0x45000000: movrv=12; break;
//         case 0xc5000000: movrv=12; sv=1; break;
//         case 0x45800000: movrv=11; break;
//         case 0xc5800000: movrv=11; sv=1; break;
//         case 0x46000000: movrv=10; break;
//         case 0xc6000000: movrv=10; sv=1; break;
//         case 0x46800000: movrv=9; break;
//         case 0xc6800000: movrv=9; sv=1; break;
//         case 0x47000000: movrv=8; break;
//         case 0xc7000000: movrv=8; sv=1; break;
//         case 0x47800000: movrv=7; break;
//         case 0xc7800000: movrv=7; sv=1; break;
//         case 0x48000000: movrv=6; break;
//         case 0xc8000000: movrv=6; sv=1; break;
//         case 0x48800000: movrv=5; break;
//         case 0xc8800000: movrv=5; sv=1; break;
//         case 0x49000000: movrv=4; break;
//         case 0xc9000000: movrv=4; sv=1; break;
//         case 0x49800000: movrv=3; break;
//         case 0xc9800000: movrv=3; sv=1; break;
//         case 0x4a000000: movrv=2; break;
//         case 0xca000000: movrv=2; sv=1; break;
//         case 0x4a800000: movrv=1; break;
//         case 0xca800000: movrv=1; sv=1; break;
//         case 0x4b000000: movlv=0; break;
//         case 0xcb000000: movlv=0; sv=1; break;
//         case 0x4b800000: movlv=1; break;
//         case 0xcb800000: movlv=1; sv=1; break;
//         case 0x4c000000: movlv=2; break;
//         case 0xcc000000: movlv=2; sv=1; break;
//         case 0x4c800000: movlv=3; break;
//         case 0xcc800000: movlv=3; sv=1; break;
//         case 0x4d000000: movlv=4; break;
//         case 0xcd000000: movlv=4; sv=1; break;
//         case 0x4d800000: movlv=5; break;
//         case 0xcd800000: movlv=5; sv=1; break;
//         case 0x4e000000: movlv=6; break;
//         case 0xce000000: movlv=6; sv=1; break;
//         case 0x4e800000: movlv=7; break;
//         case 0xce800000: movlv=7; sv=1; break;
//     }
//     nowl=4;
//     switch (movlv)
//     {
//         case 0: reg3=18; break;
//         case 1: reg3=17; break;
//         case 2: reg3=16; break;
//         case 3: reg3=15; break;
//         case 4: reg3=14; break;
//         case 5: reg3=13; break;
//         case 6: reg3=12; break;
//         case 7: reg3=11; break;
//     }
//     while(nowl)
//     {
//         alu2=alu0-alu1;
//         switch (nowl)
//         {
//             //add unit(3pc) reg2=reg0+reg1  goto nexl
//             case 1:
//             alu0=0;
//             alu1=reg1;
//             nowl=2;
//             break;
//             case 2:
//             alu0=reg0;
//             alu1=alu2;
//             nowl=3;
//             break;
//             case 3:
//             reg2=alu2;
//             nowl=nexl;
//             break;
//             case 4:
//             reg0=0x800000;
//             reg1=mv;
//             nowl=1;
//             nexl=5;
//             break;
//             case 5:
//             basev=reg2;
//             nowl=6;
//             break;
//             case 6:
//             reg2=basev;
//             nowl=reg3;
//             break;
//             case 7:
//             nowl=sv?9:8;
//             break;
//             case 8:
//             return ssv;
//             case 9:
//             alu0=0;
//             alu1=ssv;
//             nowl=10;
//             break;
//             case 10:
//             return alu2;
//             break;
//             case 11:
//             reg0=reg2;
//             reg1=reg2;
//             nowl=1;
//             nexl=12;
//             break;
//             case 12:
//             reg0=reg2;
//             reg1=reg2;
//             nowl=1;
//             nexl=13;
//             break;
//             case 13:
//             reg0=reg2;
//             reg1=reg2;
//             nowl=1;
//             nexl=14;
//             break;
//             case 14:
//             reg0=reg2;
//             reg1=reg2;
//             nowl=1;
//             nexl=15;
//             break;
//             case 15:
//             reg0=reg2;
//             reg1=reg2;
//             nowl=1;
//             nexl=16;
//             break;
//             case 16:
//             reg0=reg2;
//             reg1=reg2;
//             nowl=1;
//             nexl=17;
//             break;
//             case 17:
//             reg0=reg2;
//             reg1=reg2;
//             nowl=1;
//             nexl=18;
//             break;
//             case 18:
//             ssv=reg2>>movrv;
//             nowl=7;
//             break;
//         }
//     }
//     return 0;
    //return sv?-ssv:ssv;

    int alu0=0,alu1=0,alu2=0;
    //int reg0=0,reg1=0,reg2=0,reg3=0,reg4=0,reg5=0,reg6=0,reg7=0;
    int bw0=0,bw1=0,bw2=0,bw3=0,bw4=0,bw5=0,bw6=0,bw7=0,bw8=0,bw9=0,bw10=0,bw11=0,bw12=0,bw13=0,bw14=0,bw15=0,bw16=0,bw17=0,bw18=0,bw19=0,bw20=0,bw21=0,bw22=0,bw23=0,bw24=0,bw25=0,bw26=0,bw27=0,bw28=0,bw29=0,bw30=0,bw31=0;
    int nowl=1;
    int expv=0,sv=0;
    while(nowl)
    {
        switch(nowl)
        {
            case 1: alu0=uf;alu1=0x80000000;break;
            case 2: alu1=0x7f800000;break;
            case 3: alu1=0x1;break;
            case 4: alu1=0x2;break;
            case 5: alu1=0x4;break;
            case 6: alu1=0x8;break;
            case 7: alu1=0x10;break;
            case 8: alu1=0x20;break;
            case 9: alu1=0x40;break;
            case 10: alu1=0x80;break;
            case 11: alu1=0x100;break;
            case 12: alu1=0x200;break;
            case 13: alu1=0x400;break;
            case 14: alu1=0x800;break;
            case 15: alu1=0x1000;break;
            case 16: alu1=0x2000;break;
            case 17: alu1=0x4000;break;
            case 18: alu1=0x8000;break;
            case 19: alu1=0x10000;break;
            case 20: alu1=0x20000;break;
            case 21: alu1=0x40000;break;
            case 22: alu1=0x80000;break;
            case 23: alu1=0x100000;break;
            case 24: alu1=0x200000;break;
            case 25: alu1=0x400000;break;
            case 26: alu0=alu2;if(bw0){alu1=0xffffffff;}else{alu1=0xfffffffe;} break;
            case 27: alu0=alu2;if(bw1){alu1=0xffffffff;}else{alu1=0xfffffffd;} break;
            case 28: alu0=alu2;if(bw2){alu1=0xffffffff;}else{alu1=0xfffffffb;} break;
            case 29: alu0=alu2;if(bw3){alu1=0xffffffff;}else{alu1=0xfffffff7;} break;
            case 30: alu0=alu2;if(bw4){alu1=0xffffffff;}else{alu1=0xffffffef;} break;
            case 31: alu0=alu2;if(bw5){alu1=0xffffffff;}else{alu1=0xffffffdf;} break;
            case 32: alu0=alu2;if(bw6){alu1=0xffffffff;}else{alu1=0xffffffbf;} break;
            case 33: alu0=alu2;if(bw7){alu1=0xffffffff;}else{alu1=0xffffff7f;} break;
            case 34: alu0=alu2;if(bw8){alu1=0xffffffff;}else{alu1=0xfffffeff;} break;
            case 35: alu0=alu2;if(bw9){alu1=0xffffffff;}else{alu1=0xfffffdff;} break;
            case 36: alu0=alu2;if(bw10){alu1=0xffffffff;}else{alu1=0xfffffbff;} break;
            case 37: alu0=alu2;if(bw11){alu1=0xffffffff;}else{alu1=0xfffff7ff;} break;
            case 38: alu0=alu2;if(bw12){alu1=0xffffffff;}else{alu1=0xffffefff;} break;
            case 39: alu0=alu2;if(bw13){alu1=0xffffffff;}else{alu1=0xffffdfff;} break;
            case 40: alu0=alu2;if(bw14){alu1=0xffffffff;}else{alu1=0xffffbfff;} break;
            case 41: alu0=alu2;if(bw15){alu1=0xffffffff;}else{alu1=0xffff7fff;} break;
            case 42: alu0=alu2;if(bw16){alu1=0xffffffff;}else{alu1=0xfffeffff;} break;
            case 43: alu0=alu2;if(bw17){alu1=0xffffffff;}else{alu1=0xfffdffff;} break;
            case 44: alu0=alu2;if(bw18){alu1=0xffffffff;}else{alu1=0xfffbffff;} break;
            case 45: alu0=alu2;if(bw19){alu1=0xffffffff;}else{alu1=0xfff7ffff;} break;
            case 46: alu0=alu2;if(bw20){alu1=0xffffffff;}else{alu1=0xffefffff;} break;
            case 47: alu0=alu2;if(bw21){alu1=0xffffffff;}else{alu1=0xffdfffff;} break;
            case 48: alu0=alu2;if(bw22){alu1=0xffffffff;}else{alu1=0xffbfffff;} break;
            case 49: alu0=alu2;if(bw23){alu1=0xffffffff;}else{alu1=0xff7fffff;} break;
            case 50: alu0=alu2;if(bw24){alu1=0xffffffff;}else{alu1=0xfeffffff;} break;
            case 51: alu0=alu2;if(bw25){alu1=0xffffffff;}else{alu1=0xfdffffff;} break;
            case 52: alu0=alu2;if(bw26){alu1=0xffffffff;}else{alu1=0xfbffffff;} break;
            case 53: alu0=alu2;if(bw27){alu1=0xffffffff;}else{alu1=0xf7ffffff;} break;
            case 54: alu0=alu2;if(bw28){alu1=0xffffffff;}else{alu1=0xefffffff;} break;
            case 55: alu0=alu2;if(bw29){alu1=0xffffffff;}else{alu1=0xdfffffff;} break;
            case 56: alu0=alu2;if(bw30){alu1=0xffffffff;}else{alu1=0xbfffffff;} break;
            case 57: alu0=alu2;if(bw31){alu1=0xffffffff;}else{alu1=0x7fffffff;} break;
        }
        alu2=alu0&alu1;
        switch(nowl)
        {
            case 1: sv=alu2;nowl=2;break;
            case 2: expv=alu2;
            switch(expv)
            {
                case 0x0: case 0x800000: case 0x1000000: case 0x1800000: case 0x2000000: case 0x2800000: case 0x3000000: case 0x3800000: case 0x4000000: case 0x4800000: case 0x5000000: case 0x5800000: case 0x6000000: case 0x6800000: case 0x7000000: case 0x7800000: case 0x8000000: case 0x8800000: case 0x9000000: case 0x9800000: case 0xa000000: case 0xa800000: case 0xb000000: case 0xb800000: case 0xc000000: case 0xc800000: case 0xd000000: case 0xd800000: case 0xe000000: case 0xe800000: case 0xf000000: case 0xf800000: case 0x10000000: case 0x10800000: case 0x11000000: case 0x11800000: case 0x12000000: case 0x12800000: case 0x13000000: case 0x13800000: case 0x14000000: case 0x14800000: case 0x15000000: case 0x15800000: case 0x16000000: case 0x16800000: case 0x17000000: case 0x17800000: case 0x18000000: case 0x18800000: case 0x19000000: case 0x19800000: case 0x1a000000: case 0x1a800000: case 0x1b000000: case 0x1b800000: case 0x1c000000: case 0x1c800000: case 0x1d000000: case 0x1d800000: case 0x1e000000: case 0x1e800000: case 0x1f000000: case 0x1f800000: case 0x20000000: case 0x20800000: case 0x21000000: case 0x21800000: case 0x22000000: case 0x22800000: case 0x23000000: case 0x23800000: case 0x24000000: case 0x24800000: case 0x25000000: case 0x25800000: case 0x26000000: case 0x26800000: case 0x27000000: case 0x27800000: case 0x28000000: case 0x28800000: case 0x29000000: case 0x29800000: case 0x2a000000: case 0x2a800000: case 0x2b000000: case 0x2b800000: case 0x2c000000: case 0x2c800000: case 0x2d000000: case 0x2d800000: case 0x2e000000: case 0x2e800000: case 0x2f000000: case 0x2f800000: case 0x30000000: case 0x30800000: case 0x31000000: case 0x31800000: case 0x32000000: case 0x32800000: case 0x33000000: case 0x33800000: case 0x34000000: case 0x34800000: case 0x35000000: case 0x35800000: case 0x36000000: case 0x36800000: case 0x37000000: case 0x37800000: case 0x38000000: case 0x38800000: case 0x39000000: case 0x39800000: case 0x3a000000: case 0x3a800000: case 0x3b000000: case 0x3b800000: case 0x3c000000: case 0x3c800000: case 0x3d000000: case 0x3d800000: case 0x3e000000: case 0x3e800000: case 0x3f000000: return 0;
                case 0x4f000000: case 0x4f800000: case 0x50000000: case 0x50800000: case 0x51000000: case 0x51800000: case 0x52000000: case 0x52800000: case 0x53000000: case 0x53800000: case 0x54000000: case 0x54800000: case 0x55000000: case 0x55800000: case 0x56000000: case 0x56800000: case 0x57000000: case 0x57800000: case 0x58000000: case 0x58800000: case 0x59000000: case 0x59800000: case 0x5a000000: case 0x5a800000: case 0x5b000000: case 0x5b800000: case 0x5c000000: case 0x5c800000: case 0x5d000000: case 0x5d800000: case 0x5e000000: case 0x5e800000: case 0x5f000000: case 0x5f800000: case 0x60000000: case 0x60800000: case 0x61000000: case 0x61800000: case 0x62000000: case 0x62800000: case 0x63000000: case 0x63800000: case 0x64000000: case 0x64800000: case 0x65000000: case 0x65800000: case 0x66000000: case 0x66800000: case 0x67000000: case 0x67800000: case 0x68000000: case 0x68800000: case 0x69000000: case 0x69800000: case 0x6a000000: case 0x6a800000: case 0x6b000000: case 0x6b800000: case 0x6c000000: case 0x6c800000: case 0x6d000000: case 0x6d800000: case 0x6e000000: case 0x6e800000: case 0x6f000000: case 0x6f800000: case 0x70000000: case 0x70800000: case 0x71000000: case 0x71800000: case 0x72000000: case 0x72800000: case 0x73000000: case 0x73800000: case 0x74000000: case 0x74800000: case 0x75000000: case 0x75800000: case 0x76000000: case 0x76800000: case 0x77000000: case 0x77800000: case 0x78000000: case 0x78800000: case 0x79000000: case 0x79800000: case 0x7a000000: case 0x7a800000: case 0x7b000000: case 0x7b800000: case 0x7c000000: case 0x7c800000: case 0x7d000000: case 0x7d800000: case 0x7e000000: case 0x7e800000: case 0x7f000000: case 0x7f800000: return 0x80000000u;
            } nowl=3;break;
            case 3: bw0=alu2;nowl=4;break;
            case 4: bw1=alu2;nowl=5;break;
            case 5: bw2=alu2;nowl=6;break;
            case 6: bw3=alu2;nowl=7;break;
            case 7: bw4=alu2;nowl=8;break;
            case 8: bw5=alu2;nowl=9;break;
            case 9: bw6=alu2;nowl=10;break;
            case 10: bw7=alu2;nowl=11;break;
            case 11: bw8=alu2;nowl=12;break;
            case 12: bw9=alu2;nowl=13;break;
            case 13: bw10=alu2;nowl=14;break;
            case 14: bw11=alu2;nowl=15;break;
            case 15: bw12=alu2;nowl=16;break;
            case 16: bw13=alu2;nowl=17;break;
            case 17: bw14=alu2;nowl=18;break;
            case 18: bw15=alu2;nowl=19;break;
            case 19: bw16=alu2;nowl=20;break;
            case 20: bw17=alu2;nowl=21;break;
            case 21: bw18=alu2;nowl=22;break;
            case 22: bw19=alu2;nowl=23;break;
            case 23: bw20=alu2;nowl=24;break;
            case 24: bw21=alu2;nowl=25;break;
            case 25: bw22=alu2;nowl=26;bw23=1;
            switch(expv)
            {
                case 0x3f800000: case 0x40800000: case 0x41800000: case 0x42800000: case 0x43800000: case 0x44800000: case 0x45800000: case 0x46800000: case 0x47800000: case 0x48800000: case 0x49800000: case 0x4a800000:
                bw0=bw1;bw1=bw2;bw2=bw3;bw3=bw4;bw4=bw5;bw5=bw6;bw6=bw7;bw7=bw8;bw8=bw9;bw9=bw10;bw10=bw11;bw11=bw12;bw12=bw13;bw13=bw14;bw14=bw15;bw15=bw16;bw16=bw17;bw17=bw18;bw18=bw19;bw19=bw20;bw20=bw21;bw21=bw22;bw22=bw23;bw23=0;
            }
            switch(expv)
            {
                case 0x3f800000: case 0x40000000: case 0x41800000: case 0x42000000: case 0x43800000: case 0x44000000: case 0x45800000: case 0x46000000: case 0x47800000: case 0x48000000: case 0x49800000: case 0x4a000000:
                bw0=bw2;bw1=bw3;bw2=bw4;bw3=bw5;bw4=bw6;bw5=bw7;bw6=bw8;bw7=bw9;bw8=bw10;bw9=bw11;bw10=bw12;bw11=bw13;bw12=bw14;bw13=bw15;bw14=bw16;bw15=bw17;bw16=bw18;bw17=bw19;bw18=bw20;bw19=bw21;bw20=bw22;bw21=bw23;bw22=0;bw23=0;
            }
            switch(expv)
            {
                case 0x3f800000: case 0x40000000: case 0x40800000: case 0x41000000: case 0x43800000: case 0x44000000: case 0x44800000: case 0x45000000: case 0x47800000: case 0x48000000: case 0x48800000: case 0x49000000:
                bw0=bw4;bw1=bw5;bw2=bw6;bw3=bw7;bw4=bw8;bw5=bw9;bw6=bw10;bw7=bw11;bw8=bw12;bw9=bw13;bw10=bw14;bw11=bw15;bw12=bw16;bw13=bw17;bw14=bw18;bw15=bw19;bw16=bw20;bw17=bw21;bw18=bw22;bw19=bw23;bw20=0;bw21=0;bw22=0;bw23=0;
            }
            switch(expv)
            {
                case 0x43800000: case 0x44000000: case 0x44800000: case 0x45000000: case 0x45800000: case 0x46000000: case 0x46800000: case 0x47000000:
                bw0=bw8;bw1=bw9;bw2=bw10;bw3=bw11;bw4=bw12;bw5=bw13;bw6=bw14;bw7=bw15;bw8=bw16;bw9=bw17;bw10=bw18;bw11=bw19;bw12=bw20;bw13=bw21;bw14=bw22;bw15=bw23;bw16=0;bw17=0;bw18=0;bw19=0;bw20=0;bw21=0;bw22=0;bw23=0;
            }
            switch(expv)
            {
                case 0x3f800000: case 0x40000000: case 0x40800000: case 0x41000000: case 0x41800000: case 0x42000000: case 0x42800000: case 0x43000000:
                bw0=bw16;bw1=bw17;bw2=bw18;bw3=bw19;bw4=bw20;bw5=bw21;bw6=bw22;bw7=bw23;bw8=0;bw9=0;bw10=0;bw11=0;bw12=0;bw13=0;bw14=0;bw15=0;bw16=0;bw17=0;bw18=0;bw19=0;bw20=0;bw21=0;bw22=0;bw23=0;
            }
            switch(expv)
            {
                case 0x4b800000: case 0x4c800000: case 0x4d800000: case 0x4e800000:
                bw24=bw23;bw23=bw22;bw22=bw21;bw21=bw20;bw20=bw19;bw19=bw18;bw18=bw17;bw17=bw16;bw16=bw15;bw15=bw14;bw14=bw13;bw13=bw12;bw12=bw11;bw11=bw10;bw10=bw9;bw9=bw8;bw8=bw7;bw7=bw6;bw6=bw5;bw5=bw4;bw4=bw3;bw3=bw2;bw2=bw1;bw1=bw0;bw0=0;
            }
            switch(expv)
            {
                case 0x4c000000: case 0x4c800000: case 0x4e000000: case 0x4e800000:
                bw26=bw24;bw25=bw23;bw24=bw22;bw23=bw21;bw22=bw20;bw21=bw19;bw20=bw18;bw19=bw17;bw18=bw16;bw17=bw15;bw16=bw14;bw15=bw13;bw14=bw12;bw13=bw11;bw12=bw10;bw11=bw9;bw10=bw8;bw9=bw7;bw8=bw6;bw7=bw5;bw6=bw4;bw5=bw3;bw4=bw2;bw3=bw1;bw2=bw0;bw0=0;bw1=0;
            }
            switch(expv)
            {
                case 0x4d000000: case 0x4d800000: case 0x4e000000: case 0x4e800000:
                bw30=bw26;bw29=bw25;bw28=bw24;bw27=bw23;bw26=bw22;bw25=bw21;bw24=bw20;bw23=bw19;bw22=bw18;bw21=bw17;bw20=bw16;bw19=bw15;bw18=bw14;bw17=bw13;bw16=bw12;bw15=bw11;bw14=bw10;bw13=bw9;bw12=bw8;bw11=bw7;bw10=bw6;bw9=bw5;bw8=bw4;bw7=bw3;bw6=bw2;bw5=bw1;bw4=bw0;bw0=0;bw1=0;bw2=0;bw3=0;
            }
            // if(sv)
            // {
            //     if(bw0){if(reg0){bw0=0;}else{reg0=1;}}else{if(reg0){bw0=1;}else{}}
            //     if(bw1){if(reg0){bw1=0;}else{reg0=1;}}else{if(reg0){bw1=1;}else{}}
            //     if(bw2){if(reg0){bw2=0;}else{reg0=1;}}else{if(reg0){bw2=1;}else{}}
            //     if(bw3){if(reg0){bw3=0;}else{reg0=1;}}else{if(reg0){bw3=1;}else{}}
            //     if(bw4){if(reg0){bw4=0;}else{reg0=1;}}else{if(reg0){bw4=1;}else{}}
            //     if(bw5){if(reg0){bw5=0;}else{reg0=1;}}else{if(reg0){bw5=1;}else{}}
            //     if(bw6){if(reg0){bw6=0;}else{reg0=1;}}else{if(reg0){bw6=1;}else{}}
            //     if(bw7){if(reg0){bw7=0;}else{reg0=1;}}else{if(reg0){bw7=1;}else{}}
            //     if(bw8){if(reg0){bw8=0;}else{reg0=1;}}else{if(reg0){bw8=1;}else{}}
            //     if(bw9){if(reg0){bw9=0;}else{reg0=1;}}else{if(reg0){bw9=1;}else{}}
            //     if(bw10){if(reg0){bw10=0;}else{reg0=1;}}else{if(reg0){bw10=1;}else{}}
            //     if(bw11){if(reg0){bw11=0;}else{reg0=1;}}else{if(reg0){bw11=1;}else{}}
            //     if(bw12){if(reg0){bw12=0;}else{reg0=1;}}else{if(reg0){bw12=1;}else{}}
            //     if(bw13){if(reg0){bw13=0;}else{reg0=1;}}else{if(reg0){bw13=1;}else{}}
            //     if(bw14){if(reg0){bw14=0;}else{reg0=1;}}else{if(reg0){bw14=1;}else{}}
            //     if(bw15){if(reg0){bw15=0;}else{reg0=1;}}else{if(reg0){bw15=1;}else{}}
            //     if(bw16){if(reg0){bw16=0;}else{reg0=1;}}else{if(reg0){bw16=1;}else{}}
            //     if(bw17){if(reg0){bw17=0;}else{reg0=1;}}else{if(reg0){bw17=1;}else{}}
            //     if(bw18){if(reg0){bw18=0;}else{reg0=1;}}else{if(reg0){bw18=1;}else{}}
            //     if(bw19){if(reg0){bw19=0;}else{reg0=1;}}else{if(reg0){bw19=1;}else{}}
            //     if(bw20){if(reg0){bw20=0;}else{reg0=1;}}else{if(reg0){bw20=1;}else{}}
            //     if(bw21){if(reg0){bw21=0;}else{reg0=1;}}else{if(reg0){bw21=1;}else{}}
            //     if(bw22){if(reg0){bw22=0;}else{reg0=1;}}else{if(reg0){bw22=1;}else{}}
            //     if(bw23){if(reg0){bw23=0;}else{reg0=1;}}else{if(reg0){bw23=1;}else{}}
            //     if(bw24){if(reg0){bw24=0;}else{reg0=1;}}else{if(reg0){bw24=1;}else{}}
            //     if(bw25){if(reg0){bw25=0;}else{reg0=1;}}else{if(reg0){bw25=1;}else{}}
            //     if(bw26){if(reg0){bw26=0;}else{reg0=1;}}else{if(reg0){bw26=1;}else{}}
            //     if(bw27){if(reg0){bw27=0;}else{reg0=1;}}else{if(reg0){bw27=1;}else{}}
            //     if(bw28){if(reg0){bw28=0;}else{reg0=1;}}else{if(reg0){bw28=1;}else{}}
            //     if(bw29){if(reg0){bw29=0;}else{reg0=1;}}else{if(reg0){bw29=1;}else{}}
            //     if(bw30){if(reg0){bw30=0;}else{reg0=1;}}else{if(reg0){bw30=1;}else{}}
            //     bw31=1;
            // }
            alu2=0xffffffff;break;
            case 26: nowl=27;break;
            case 27: nowl=28;break;
            case 28: nowl=29;break;
            case 29: nowl=30;break;
            case 30: nowl=31;break;
            case 31: nowl=32;break;
            case 32: nowl=33;break;
            case 33: nowl=34;break;
            case 34: nowl=35;break;
            case 35: nowl=36;break;
            case 36: nowl=37;break;
            case 37: nowl=38;break;
            case 38: nowl=39;break;
            case 39: nowl=40;break;
            case 40: nowl=41;break;
            case 41: nowl=42;break;
            case 42: nowl=43;break;
            case 43: nowl=44;break;
            case 44: nowl=45;break;
            case 45: nowl=46;break;
            case 46: nowl=47;break;
            case 47: nowl=48;break;
            case 48: nowl=49;break;
            case 49: nowl=50;break;
            case 50: nowl=51;break;
            case 51: nowl=52;break;
            case 52: nowl=53;break;
            case 53: nowl=54;break;
            case 54: nowl=55;break;
            case 55: nowl=56;break;
            case 56: nowl=57;break;
            case 57: nowl=0;break;
        }
    }
    //return reg7;
    return sv?-alu2:alu2;
}
/* 
 * float_pwr2 - Return bit-level equivalent of the expression 2.0^x
 *   (2.0 raised to the power x) for any 32-bit integer x.
 *
 *   The unsigned value that is returned should have the identical bit
 *   representation as the single-precision floating-point number 2.0^x.
 *   If the result is too small to be represented as a denorm, return
 *   0. If too large, return +INF.
 * 
 *   Legal ops: Any integer/unsigned operations incl. ||, &&. Also if, while 
 *   Max ops: 30 
 *   Rating: 4
 */
unsigned float_pwr2(int x) {
    // Version 2  3ops
    // the lines removed was the original version which has 7ops
    // int ja=127+x;
    // int jb=149+x;
    // if(x>127)   return 0x7f800000;//too large, return inf
    // if(jb<0)  return 0;//too small, return 0
    // if(ja<=0)  return 1<<jb;//subnormal
    // return ja<<23;//not subnormal
    // these code was generated by the following python code, reduce many ops.
    // if not return, we have -149<=x<=127, not too much, we can use many switch-case to cover all conditions
    unsigned xu=x;//unsigned x
    if(x>127)   return 0x7f800000;
    /*
txt=""
for i in range(-149,128):
 ja=127+i
 jb=149+i
 if ja<=0:
  pans=1<<jb
 else:
  pans=ja<<23
 txt=txt+"case %s: return %d;\n"%(hex(i%(2**32)),pans)
print(txt)
    */
    switch (xu)//use unsigned hex to reduce ops
    {
        case 0xffffff6b: return 1;
        case 0xffffff6c: return 2;
        case 0xffffff6d: return 4;
        case 0xffffff6e: return 8;
        case 0xffffff6f: return 16;
        case 0xffffff70: return 32;
        case 0xffffff71: return 64;
        case 0xffffff72: return 128;
        case 0xffffff73: return 256;
        case 0xffffff74: return 512;
        case 0xffffff75: return 1024;
        case 0xffffff76: return 2048;
        case 0xffffff77: return 4096;
        case 0xffffff78: return 8192;
        case 0xffffff79: return 16384;
        case 0xffffff7a: return 32768;
        case 0xffffff7b: return 65536;
        case 0xffffff7c: return 131072;
        case 0xffffff7d: return 262144;
        case 0xffffff7e: return 524288;
        case 0xffffff7f: return 1048576;
        case 0xffffff80: return 2097152;
        case 0xffffff81: return 4194304;
        case 0xffffff82: return 8388608;
        case 0xffffff83: return 16777216;
        case 0xffffff84: return 25165824;
        case 0xffffff85: return 33554432;
        case 0xffffff86: return 41943040;
        case 0xffffff87: return 50331648;
        case 0xffffff88: return 58720256;
        case 0xffffff89: return 67108864;
        case 0xffffff8a: return 75497472;
        case 0xffffff8b: return 83886080;
        case 0xffffff8c: return 92274688;
        case 0xffffff8d: return 100663296;
        case 0xffffff8e: return 109051904;
        case 0xffffff8f: return 117440512;
        case 0xffffff90: return 125829120;
        case 0xffffff91: return 134217728;
        case 0xffffff92: return 142606336;
        case 0xffffff93: return 150994944;
        case 0xffffff94: return 159383552;
        case 0xffffff95: return 167772160;
        case 0xffffff96: return 176160768;
        case 0xffffff97: return 184549376;
        case 0xffffff98: return 192937984;
        case 0xffffff99: return 201326592;
        case 0xffffff9a: return 209715200;
        case 0xffffff9b: return 218103808;
        case 0xffffff9c: return 226492416;
        case 0xffffff9d: return 234881024;
        case 0xffffff9e: return 243269632;
        case 0xffffff9f: return 251658240;
        case 0xffffffa0: return 260046848;
        case 0xffffffa1: return 268435456;
        case 0xffffffa2: return 276824064;
        case 0xffffffa3: return 285212672;
        case 0xffffffa4: return 293601280;
        case 0xffffffa5: return 301989888;
        case 0xffffffa6: return 310378496;
        case 0xffffffa7: return 318767104;
        case 0xffffffa8: return 327155712;
        case 0xffffffa9: return 335544320;
        case 0xffffffaa: return 343932928;
        case 0xffffffab: return 352321536;
        case 0xffffffac: return 360710144;
        case 0xffffffad: return 369098752;
        case 0xffffffae: return 377487360;
        case 0xffffffaf: return 385875968;
        case 0xffffffb0: return 394264576;
        case 0xffffffb1: return 402653184;
        case 0xffffffb2: return 411041792;
        case 0xffffffb3: return 419430400;
        case 0xffffffb4: return 427819008;
        case 0xffffffb5: return 436207616;
        case 0xffffffb6: return 444596224;
        case 0xffffffb7: return 452984832;
        case 0xffffffb8: return 461373440;
        case 0xffffffb9: return 469762048;
        case 0xffffffba: return 478150656;
        case 0xffffffbb: return 486539264;
        case 0xffffffbc: return 494927872;
        case 0xffffffbd: return 503316480;
        case 0xffffffbe: return 511705088;
        case 0xffffffbf: return 520093696;
        case 0xffffffc0: return 528482304;
        case 0xffffffc1: return 536870912;
        case 0xffffffc2: return 545259520;
        case 0xffffffc3: return 553648128;
        case 0xffffffc4: return 562036736;
        case 0xffffffc5: return 570425344;
        case 0xffffffc6: return 578813952;
        case 0xffffffc7: return 587202560;
        case 0xffffffc8: return 595591168;
        case 0xffffffc9: return 603979776;
        case 0xffffffca: return 612368384;
        case 0xffffffcb: return 620756992;
        case 0xffffffcc: return 629145600;
        case 0xffffffcd: return 637534208;
        case 0xffffffce: return 645922816;
        case 0xffffffcf: return 654311424;
        case 0xffffffd0: return 662700032;
        case 0xffffffd1: return 671088640;
        case 0xffffffd2: return 679477248;
        case 0xffffffd3: return 687865856;
        case 0xffffffd4: return 696254464;
        case 0xffffffd5: return 704643072;
        case 0xffffffd6: return 713031680;
        case 0xffffffd7: return 721420288;
        case 0xffffffd8: return 729808896;
        case 0xffffffd9: return 738197504;
        case 0xffffffda: return 746586112;
        case 0xffffffdb: return 754974720;
        case 0xffffffdc: return 763363328;
        case 0xffffffdd: return 771751936;
        case 0xffffffde: return 780140544;
        case 0xffffffdf: return 788529152;
        case 0xffffffe0: return 796917760;
        case 0xffffffe1: return 805306368;
        case 0xffffffe2: return 813694976;
        case 0xffffffe3: return 822083584;
        case 0xffffffe4: return 830472192;
        case 0xffffffe5: return 838860800;
        case 0xffffffe6: return 847249408;
        case 0xffffffe7: return 855638016;
        case 0xffffffe8: return 864026624;
        case 0xffffffe9: return 872415232;
        case 0xffffffea: return 880803840;
        case 0xffffffeb: return 889192448;
        case 0xffffffec: return 897581056;
        case 0xffffffed: return 905969664;
        case 0xffffffee: return 914358272;
        case 0xffffffef: return 922746880;
        case 0xfffffff0: return 931135488;
        case 0xfffffff1: return 939524096;
        case 0xfffffff2: return 947912704;
        case 0xfffffff3: return 956301312;
        case 0xfffffff4: return 964689920;
        case 0xfffffff5: return 973078528;
        case 0xfffffff6: return 981467136;
        case 0xfffffff7: return 989855744;
        case 0xfffffff8: return 998244352;
        case 0xfffffff9: return 1006632960;
        case 0xfffffffa: return 1015021568;
        case 0xfffffffb: return 1023410176;
        case 0xfffffffc: return 1031798784;
        case 0xfffffffd: return 1040187392;
        case 0xfffffffe: return 1048576000;
        case 0xffffffff: return 1056964608;
        case 0x0: return 1065353216;
        case 0x1: return 1073741824;
        case 0x2: return 1082130432;
        case 0x3: return 1090519040;
        case 0x4: return 1098907648;
        case 0x5: return 1107296256;
        case 0x6: return 1115684864;
        case 0x7: return 1124073472;
        case 0x8: return 1132462080;
        case 0x9: return 1140850688;
        case 0xa: return 1149239296;
        case 0xb: return 1157627904;
        case 0xc: return 1166016512;
        case 0xd: return 1174405120;
        case 0xe: return 1182793728;
        case 0xf: return 1191182336;
        case 0x10: return 1199570944;
        case 0x11: return 1207959552;
        case 0x12: return 1216348160;
        case 0x13: return 1224736768;
        case 0x14: return 1233125376;
        case 0x15: return 1241513984;
        case 0x16: return 1249902592;
        case 0x17: return 1258291200;
        case 0x18: return 1266679808;
        case 0x19: return 1275068416;
        case 0x1a: return 1283457024;
        case 0x1b: return 1291845632;
        case 0x1c: return 1300234240;
        case 0x1d: return 1308622848;
        case 0x1e: return 1317011456;
        case 0x1f: return 1325400064;
        case 0x20: return 1333788672;
        case 0x21: return 1342177280;
        case 0x22: return 1350565888;
        case 0x23: return 1358954496;
        case 0x24: return 1367343104;
        case 0x25: return 1375731712;
        case 0x26: return 1384120320;
        case 0x27: return 1392508928;
        case 0x28: return 1400897536;
        case 0x29: return 1409286144;
        case 0x2a: return 1417674752;
        case 0x2b: return 1426063360;
        case 0x2c: return 1434451968;
        case 0x2d: return 1442840576;
        case 0x2e: return 1451229184;
        case 0x2f: return 1459617792;
        case 0x30: return 1468006400;
        case 0x31: return 1476395008;
        case 0x32: return 1484783616;
        case 0x33: return 1493172224;
        case 0x34: return 1501560832;
        case 0x35: return 1509949440;
        case 0x36: return 1518338048;
        case 0x37: return 1526726656;
        case 0x38: return 1535115264;
        case 0x39: return 1543503872;
        case 0x3a: return 1551892480;
        case 0x3b: return 1560281088;
        case 0x3c: return 1568669696;
        case 0x3d: return 1577058304;
        case 0x3e: return 1585446912;
        case 0x3f: return 1593835520;
        case 0x40: return 1602224128;
        case 0x41: return 1610612736;
        case 0x42: return 1619001344;
        case 0x43: return 1627389952;
        case 0x44: return 1635778560;
        case 0x45: return 1644167168;
        case 0x46: return 1652555776;
        case 0x47: return 1660944384;
        case 0x48: return 1669332992;
        case 0x49: return 1677721600;
        case 0x4a: return 1686110208;
        case 0x4b: return 1694498816;
        case 0x4c: return 1702887424;
        case 0x4d: return 1711276032;
        case 0x4e: return 1719664640;
        case 0x4f: return 1728053248;
        case 0x50: return 1736441856;
        case 0x51: return 1744830464;
        case 0x52: return 1753219072;
        case 0x53: return 1761607680;
        case 0x54: return 1769996288;
        case 0x55: return 1778384896;
        case 0x56: return 1786773504;
        case 0x57: return 1795162112;
        case 0x58: return 1803550720;
        case 0x59: return 1811939328;
        case 0x5a: return 1820327936;
        case 0x5b: return 1828716544;
        case 0x5c: return 1837105152;
        case 0x5d: return 1845493760;
        case 0x5e: return 1853882368;
        case 0x5f: return 1862270976;
        case 0x60: return 1870659584;
        case 0x61: return 1879048192;
        case 0x62: return 1887436800;
        case 0x63: return 1895825408;
        case 0x64: return 1904214016;
        case 0x65: return 1912602624;
        case 0x66: return 1920991232;
        case 0x67: return 1929379840;
        case 0x68: return 1937768448;
        case 0x69: return 1946157056;
        case 0x6a: return 1954545664;
        case 0x6b: return 1962934272;
        case 0x6c: return 1971322880;
        case 0x6d: return 1979711488;
        case 0x6e: return 1988100096;
        case 0x6f: return 1996488704;
        case 0x70: return 2004877312;
        case 0x71: return 2013265920;
        case 0x72: return 2021654528;
        case 0x73: return 2030043136;
        case 0x74: return 2038431744;
        case 0x75: return 2046820352;
        case 0x76: return 2055208960;
        case 0x77: return 2063597568;
        case 0x78: return 2071986176;
        case 0x79: return 2080374784;
        case 0x7a: return 2088763392;
        case 0x7b: return 2097152000;
        case 0x7c: return 2105540608;
        case 0x7d: return 2113929216;
        case 0x7e: return 2122317824;
        case 0x7f: return 2130706432;
        default: return 0;//too small
    }
}


/*
my VM Searcher
Build a stack machine to calc

#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<map>
using namespace std;
template<typename __T>
inline void read(__T &x)
{
    x=0;
    int f=1;char c=getchar();
    while(!isdigit(c)){if(c=='-')   f=-1;c=getchar();}
    while(isdigit(c))   {x=x*10+c-'0';c=getchar();}
    x*=f;
}
enum OPCODE: unsigned char
{
    PUSH=0x00,
    LOAD=0x10,
    STOR,
    INOT=0x20,
    IAND,
    IOR,
    IXOR,
    IADD=0x30,
    ISAR=0x40,
    ISAL,
    BNOT=0x50,
    INVALID=0xff
};
struct code
{
    OPCODE opcode;
    int val;
};

const int MAX_OPS=9;
const int MAX_CHECK_SAMPLES=1;
const int MAX_TEST_SAMPLES=5;
const int MAX_STORAGE=4;
const int INPUT_SIZE=1;
struct input_t
{
    int s[INPUT_SIZE];
};
int rightFunction(input_t inp)
{
    int x=inp.s[0];
    return x==5?1:x+1;
}
input_t getSample(int id)
{
    input_t ret;
    ret.s[0]=id+1;
    return ret;
}
int getCodes(code* arr,int stackDepth,int storageSize)
{
    int tot=0;
    //PUSH
    for(int i=0;i<=16;i++)
        arr[tot++]=code{PUSH,i};
    arr[tot++]=code{PUSH,27};
    arr[tot++]=code{PUSH,28};
    arr[tot++]=code{PUSH,29};
    arr[tot++]=code{PUSH,30};
    arr[tot++]=code{PUSH,31};
    arr[tot++]=code{PUSH,32};
    //LOAD
    for(int i=0;i<storageSize;i++)
        arr[tot++]=code{LOAD,i};
    if(stackDepth<1)    return tot;
    //STOR
    if(storageSize<MAX_STORAGE)
        arr[tot++]=code{STOR,0};
    //CALC
    arr[tot++]=code{INOT,0};
    arr[tot++]=code{BNOT,0};
    if(stackDepth<2)    return tot;
    arr[tot++]=code{IAND,0};
    arr[tot++]=code{IOR,0};
    //arr[tot++]=code{IXOR,0};
    arr[tot++]=code{IADD,0};
    arr[tot++]=code{ISAR,0};
    arr[tot++]=code{ISAL,0};
    return tot;
}
const int MAX_CODES=50;


struct runtime
{
    int stack[MAX_OPS];
    int stop;
    int storage[MAX_STORAGE];
    int ttop;
    runtime()
    {
        stop=ttop=0;
    }
    runtime(input_t input)
    {
        stop=0;
        ttop=INPUT_SIZE;
        for(int i=0;i<INPUT_SIZE;i++)
            storage[i]=input.s[i];
    }
    int spop()
    {
        return stack[--stop];
    }
    void spush(int x)
    {
        stack[stop++]=x;
    }
};

bool runCode(runtime& state,code nowcode)
{
    int a,b;
    switch (nowcode.opcode)
    {
        case PUSH:
        state.spush(nowcode.val);
        break;
        case LOAD:
        state.spush(state.storage[nowcode.val]);
        break;
        case STOR:
        state.storage[state.ttop++]=state.spop();
        break;
        case INOT:
        a=state.spop();
        state.spush(~a);
        break;
        case BNOT:
        a=state.spop();
        state.spush(!a);
        break;
        case IAND:
        a=state.spop();
        b=state.spop();
        state.spush(a&b);
        break;
        case IOR:
        a=state.spop();
        b=state.spop();
        state.spush(a|b);
        break;
        case IXOR:
        a=state.spop();
        b=state.spop();
        state.spush(a^b);
        break;
        case IADD:
        a=state.spop();
        b=state.spop();
        state.spush(a+b);
        break;
        case ISAR:
        a=state.spop();
        b=state.spop();
        state.spush(a>>b);
        break;
        case ISAL:
        a=state.spop();
        b=state.spop();
        state.spush(a<<b);
        break;
        default:
        cerr<<"ERROR "<<nowcode.opcode<<endl;
        return 0;
    }
    return 1;
}
bool checkAll(code* codes,int codel)
{
    for(int i=0;i<MAX_TEST_SAMPLES;i++)
    {
        input_t ni=getSample(i);
        int no=rightFunction(ni);
        runtime nowrt(ni);
        for(int j=0;j<codel;j++)
        {
            bool g=runCode(nowrt,codes[j]);
            if(!g)  return 0;
        }
        if(nowrt.stop<1)    return 0;
        int ans=nowrt.spop();
        if(ans!=no) return 0;
    }
    return 1;
}

struct runtimechecker
{
    runtime s[MAX_CHECK_SAMPLES];
    runtimechecker()
    {
        for(int i=0;i<MAX_CHECK_SAMPLES;i++)
            s[i]=runtime(getSample(i));
    }
    runtimechecker(input_t* inps)
    {
        for(int i=0;i<MAX_CHECK_SAMPLES;i++)
            s[i]=runtime(inps[i]);
    }
    bool runCode(code nowcode)
    {
        bool flag=1;
        for(int i=0;i<MAX_CHECK_SAMPLES;i++)
            flag&=(::runCode(s[i],nowcode));
        return flag;
    }
};

int ranss[MAX_CHECK_SAMPLES];
code path[MAX_OPS];
void dfs(runtimechecker& nows,int depth)
{
    if(depth>=MAX_OPS)   return;
    int slen=nows.s[0].stop;
    if(depth+slen-1>=MAX_OPS)   return;
    //check right
    bool flag=1;
    for(int i=0;i<MAX_CHECK_SAMPLES;i++)
    {
        if(nows.s[i].stop<1)
        {
            flag=0;
            break;
        }
        runtime& rt=nows.s[i];
        if(rt.stack[rt.stop-1]!=ranss[i])
        {
            flag=0;
            break;
        }
    }
    if(flag)
    {
        if(checkAll(path,depth))
        {
            cout<<"FOUND"<<endl;
            for(int i=0;i<depth;i++)
                cout<<path[i].opcode<<' '<<path[i].val<<endl;
            return;
        }
    }
    int tlen=nows.s[0].ttop;
    code nexs[MAX_CODES];
    int rlen=getCodes(nexs,slen,tlen);
    for(int i=0;i<rlen;i++)
    {
        runtimechecker nt=nows;
        nt.runCode(nexs[i]);
        path[depth]=nexs[i];
        dfs(nt,depth+1);
    }
    return;
}

void search()
{
    runtimechecker inst;
    for(int i=0;i<MAX_CHECK_SAMPLES;i++)
        ranss[i]=rightFunction(getSample(i));
    //cout<<"AA"<<endl;
    dfs(inst,0);
}

void test()
{
    code testcodes[MAX_CODES];
    int len=getCodes(testcodes,5,2);
    for(int i=0;i<len;i++)
        cout<<testcodes[i].opcode<<' '<<testcodes[i].val<<endl;
    code mo4[5]=
    {code{PUSH,1},code{LOAD,0},code{IADD,1},code{PUSH,3},code{IAND,0}};
    cout<<checkAll(mo4,5)<<endl;
    code mo4w[5]=
    {code{PUSH,1},code{LOAD,0},code{IADD,1},code{PUSH,5},code{IAND,0}};
    cout<<checkAll(mo4w,5)<<endl;
    search();
}
int main()
{
    //test();
    search();
    return 0;
}
*/
