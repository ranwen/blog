TABC=0
def rprint(st):
    print(' '*TABC*4,end='')
    print(st)

rprint("int alu0=0,alu1=0,alu2=0;")
rprint("int reg0=0,reg1=0,reg2=0,reg3=0,reg4=0,reg5=0,reg6=0,reg7=0;")
rprint("int bw"+"=0,bw".join(list(map(str,range(32))))+"=0;")
rprint("int cw"+"=0,cw".join(list(map(str,range(32))))+"=0;")
rprint("int nowl=1;")
rprint("int expv=0;")

#reg0 is doubled
#reg1 add now bit
#reg2 add carry bit

def gen_add_begin(adw):
    pd=("if(bw%d){if(cw%d){if(reg2){reg1=1;reg2=1;}else{reg1=0;reg2=1;}}\
else{if(reg2){reg1=0;reg2=1;}else{reg1=1;reg2=0;}}}\
else{if(cw%d){if(reg2){reg1=0;reg2=1;}else{reg1=1;reg2=0;}}\
else{if(reg2){reg1=1;reg2=0;}else{reg1=0;reg2=0;}}}"%(adw,adw,adw))+\
    ("alu0=alu2;if(reg1){alu1=0xffffffff;}else{alu1=0x%x;}"%(0xffffffff^(2**adw)))
    if adw>=23:
        return pd
    return "alu0=alu2;if(bw%d){alu1=0xffffffff;}else{alu1=0x%x;}"%(adw,0xffffffff^(2**adw))

def show_before():
    global TABC
    rprint("switch(nowl)")
    rprint('{')
    TABC+=1
    rprint("case 1: alu0=uf;alu1=0xff800000;break;")
    for i in range(32):
        rprint("case %d: alu1=0x%x;break;"%(2+i,2**i))
    for i in range(32):
        rprint("case %d: %s break;"%(i+34,gen_add_begin(i)))
    TABC-=1
    rprint('}')

def show_after():
    global TABC
    rprint("switch(nowl)")
    rprint('{')
    TABC+=1
    rprint("case 1: expv=alu2;")
    rprint("switch(expv)")
    rprint("{")
    TABC+=1
    rprint("case 0x7f800000: case 0xff800000: return uf;")
    rprint("case 0x7f000000: return 0x7f800000;")
    rprint("case 0xff000000: return 0xff800000;")
    rprint("case 0: reg0=1;break;")
    rprint("case 0x80000000: reg0=1;cw31=1;break;")
    rprint("default: cw23=1;break;")
    TABC-=1
    rprint('}nowl=2;break;')
    for i in range(31):
        rprint("case %d: bw%d=alu2;nowl=%d;break;"%(2+i,i,3+i))
    rprint("case %d: bw%d=alu2;nowl=%d;if(reg0){%s}alu2=0xffffffff;break;"%(2+31,31,3+31,("".join((["bw0=0;"]+["bw%d=bw%d;"%y for y in [(x+1,x) for x in range(31)]])[::-1]))))
    for i in range(31):
        rprint("case %d: nowl=%d;break;"%(34+i,35+i))
    rprint("case %d: nowl=%d;reg7=alu2;break;"%(34+31,0))
    TABC-=1
    rprint('}')

rprint("while(nowl)")
rprint("{")
TABC+=1

show_before()
rprint("alu2=alu0&alu1;")
show_after()

TABC-=1
rprint("}")
rprint("return reg7;")