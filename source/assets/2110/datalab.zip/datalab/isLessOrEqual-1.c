int isLessOrEqual(int x, int y) {
    // Version 1  8ops
    // int difh=x^y;//check different sign, to avoid sub overflow
    // old version, use De Morgan's law to reduce ops
    // int cha=~(y+(~x+1));//calc y-x, because return 1 when y==x, like y>x which has highest bit 0
    // int res=(cha&(~difh))|(x&difh);//return sub result when same sign, else return x

    // int cha=(x+(~y));//calc x-y-1, because return 1 when y==x, like y>x which has highest bit 0
    // int res=(cha)^((x^cha)&difh);//return sub result when same sign, else return x
    // return (res>>31)&1;//return highest bit

    // Version 2  7ops
    // find by computer
    int v0=x;
    int v1=y;
    int v2=(x+(~y));
    int v3=0;
    int v4=0;
    int v5=0;
    int v6=0;
    int v7=0;
v3=v1^v2;
v4=v2>>v0;
v5=v3>>31;
v6=v4>>v5;
v7=v6&1;
return v7;
}
